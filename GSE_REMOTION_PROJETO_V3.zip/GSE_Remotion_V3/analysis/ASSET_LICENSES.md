# Origem dos materiais

Os brasões gse-original.png e guarda-original.png e a narração narracao-original.mp3 foram fornecidos pelo usuário. Os originais estão preservados sem alteração. A autorização de uso decorre do pedido do usuário para a produção deste vídeo; nenhuma licença pública adicional é declarada.

escola-editorial.png e comunidade-editorial.png foram gerados especificamente para este projeto com a ferramenta de geração de imagem. São ilustrações; não representam registros fotográficos reais do GSE.

Instrument Serif Italic, Anton e Space Grotesk foram obtidas do repositório oficial google/fonts. As licenças SIL Open Font License estão junto aos arquivos de fontes em public/assets.

O vídeo de referência fornecido pelo usuário foi analisado para direção de arte; nenhum quadro dele integra o vídeo final.

## Atualização da versão 2

As imagens fachada.jpg, fachada-patio.jpg e entrada.jpg em public/assets/real-school foram enviadas pelo usuário nesta conversa para integrar o vídeo. Representam a UEB Gonçalves Dias e estão preservadas byte a byte.

objetos-v2.png e mesa-comunidade-v2.png foram gerados especificamente para o projeto. A versão 2 também usa o livro ilustrativo comunidade-editorial.png. A escola genérica escola-editorial.png permanece apenas para a composição histórica GSE-V1; não integra a versão 2. As ilustrações conceituais não representam ocorrências ou ações reais do GSE.
