import sys,json,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('HF_HOME',str(ROOT/'models'))
os.environ.setdefault('HF_XET_CACHE',str(ROOT/'models/xet-cache'))
sys.path.insert(0,str(ROOT/'python-packages'))
from faster_whisper import WhisperModel
model=WhisperModel('small',device='cpu',compute_type='int8',download_root=str(ROOT/'models'),cpu_threads=4)
segments,info=model.transcribe(str(ROOT/'public/assets/narracao-original.mp3'),language='pt',word_timestamps=True,beam_size=5,initial_prompt='GSE. Grupamento de Segurança Escolar. Guarda Municipal de São Luís. Força e Honra.')
result=[]
for s in segments:
 d={'start':s.start,'end':s.end,'text':s.text,'words':[{'start':w.start,'end':w.end,'word':w.word} for w in s.words]}
 result.append(d)
 print(json.dumps(d,ensure_ascii=False),flush=True)
json.dump(result,open(str(ROOT/'analysis/alignment.json'),'w'),ensure_ascii=False,indent=2)
