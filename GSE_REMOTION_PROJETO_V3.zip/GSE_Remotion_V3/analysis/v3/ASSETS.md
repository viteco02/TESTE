# Assets da versão 3

As três fotografias originais da UEB Gonçalves Dias foram usadas como referências de arquitetura para a criação da escola ilustrada e do portão. Não são exibidas pela composição GSE desta versão. A linguagem visual segue a miniatura editorial da primeira montagem, substituindo o edifício genérico por uma interpretação da escola real.

`escola-ueb.png`: ilustração do conjunto térreo, pátio, bancos e portão.
`portao-ueb.png`: entrada frontal; as folhas são recortadas e animadas em camadas externas no Remotion.
`objetos.png`: atlas em seis células de 512×512: mesa sem cadeiras; cadeira azul-marinho; cadeira azul-clara; relógio sem ponteiros; lâmpada; sino. Ponteiros, brilho, deslocamentos e rotações são animados na composição.

Imagens geradas com image_gen a partir das referências fornecidas e direção de arte do projeto. Os brasões e o MP3 mantêm os arquivos originais; não foram gerados ou reconstruídos.
