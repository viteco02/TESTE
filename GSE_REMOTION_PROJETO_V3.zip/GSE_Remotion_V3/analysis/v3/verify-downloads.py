"""Verify complete unauthenticated HTTPS downloads of the published artifacts."""
import json,hashlib,urllib.request
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[2]
delivery=json.loads((ROOT/'analysis/v3/github-delivery.json').read_text())
def verify(item):
 name,expected=item
 urls=[expected['download_url'],f'https://raw.githubusercontent.com/viteco02/TESTE/refs/heads/main/{name}']
 failures=[]
 for url in urls:
  try:
   request=urllib.request.Request(url,headers={'User-Agent':'GSE-Delivery-Verification/3'})
   with urllib.request.urlopen(request,timeout=120) as response:
    assert response.status==200
    digest=hashlib.sha256();size=0
    while True:
     block=response.read(2*1024*1024)
     if not block:break
     digest.update(block);size+=len(block)
    assert size==expected['bytes'],f'Size mismatch for {name}'
    assert digest.hexdigest()==expected['sha256'],f'Hash mismatch for {name}'
    return name,{'download_url':url,'resolved_url':response.geturl(),'http_status':response.status,'content_type':response.headers.get('Content-Type'),'content_disposition':response.headers.get('Content-Disposition'),'bytes':size,'sha256':digest.hexdigest(),'full_download':'passed','authentication':'none'}
  except Exception as exc:failures.append(str(exc))
 raise RuntimeError(f'Download failed for {name}: {failures}')
with ThreadPoolExecutor(max_workers=2) as executor:results=dict(executor.map(verify,delivery['artifacts'].items()))
report={'repository':delivery['repository'],'commit':delivery['commit'],'artifacts':results}
(ROOT/'analysis/v3/browser-download-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
