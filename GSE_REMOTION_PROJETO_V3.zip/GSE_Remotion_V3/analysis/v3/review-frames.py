import subprocess
from pathlib import Path
import sys
sys.path.insert(0,'python-packages')
from PIL import Image, ImageDraw
root=Path('/workspace/gse-production'); source=Path(sys.argv[1]) if len(sys.argv)>1 else root/'out/v3/GSE_PREVIEW.mp4'
series=[1.8,4.3,5.9,8.8,11.5,14.5,17.8,19.95,21.4,23.8,27.4,30.8,33.2,36.4,39.5,43.7,44.9,46.9,49,52.95,.3,.85,29.4,30.45]
for batch in range(2):
 sheet=Image.new('RGB',(1080,4*665),'#d4d7dc')
 for i,t in enumerate(series[batch*12:batch*12+12]):
  p=root/f'analysis/v3/review-{t:g}.jpg'
  subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(source),'-frames:v','1','-vf','scale=360:640','-q:v','2',str(p)],check=True)
  img=Image.open(p);x=(i%3)*360;y=(i//3)*665;sheet.paste(img,(x,y));ImageDraw.Draw(sheet).text((x+8,y+643),f'{t:.2f} s',fill='#102743')
 sheet.save(root/f'analysis/v3/review-sheet-{batch+1}.jpg',quality=92)
print('Saved 24 review frames and two contact sheets.')
