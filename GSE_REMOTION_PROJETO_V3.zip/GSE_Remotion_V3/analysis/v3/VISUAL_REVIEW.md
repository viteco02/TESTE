# Revisão visual da versão 3

## Prévia integral

Revisados 24 momentos em duas pranchas e quadros ampliados: abertura; escola segura; entrada pelo portão; apresentação dos brasões; missão; acompanhamento e risco; fortalecimento; ensino e aprendizado; construção; comunidade; movimento; proteção; celular; encerramento.

A composição usa uma escola ilustrada única, baseada na UEB Gonçalves Dias. Foram removidos os cartões fotográficos e as sequências de fotos da versão anterior. A composição principal não chama os componentes de fotos da versão 2.

Conferidos o relógio parando na palavra “parou”, a iluminação em “pensar”, o portão entreaberto em “entra”, a barreira antes de “risco”, a montagem da escola em “constrói” e o deslocamento das cadeiras em “respeito” e “proximidade”. Os movimentos são calculados pelos cues do áudio original.

## Ajustes após a prévia

- Afastamento do portão em relação à palavra ENTRA para preservar a leitura.
- Mesa e cadeiras elevadas, com espaço para as três linhas finais do trecho da comunidade e o rodapé.
- Recorte interno dos objetos da primeira linha do atlas para excluir resíduos de pixels dos objetos da segunda linha.
- Menor avanço lateral em MOVE, preservando a leitura e o sentido de deslocamento.
- Ajuste do celular elevado no encerramento para não cobrir “quem está presente”.
- Máscaras com espaço para acentos em português.

Os quadros ampliados da comunidade e do celular foram revisados após os ajustes de posição. A exportação final foi concluída e os mesmos 24 momentos foram extraídos do MP4 final para revisão. Foram reconferidos os quadros do portão aberto, comunidade, proteção final e assinatura. O resíduo do atlas abaixo da mesa foi eliminado. Texto, imagens e rodapés estão separados nas composições corrigidas.

Validação técnica: decodificação integral aprovada, H.264/yuv420p, 1080×1920, 30 fps, AAC estéreo e duração de 53.054694 s. Correlação da narração: 0.9996975055356949. Brasões, MP3 e fotografias originais preservados por hash.

SHA-256 do MP4 final: `505355e570e8661e728427cf2c381f36fff2a6749f927551741e3539a9c91577`.
