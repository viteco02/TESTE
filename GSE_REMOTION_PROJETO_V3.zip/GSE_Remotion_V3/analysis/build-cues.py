import json,re
segs=json.load(open('analysis/alignment.json'))
words=[w for s in segs for w in s['words']]
pauses=[]
log=open('analysis/audio-pauses.log').read()
starts=re.findall(r'silence_start: ([\d.]+)',log)
ends=re.findall(r'silence_end: ([\d.]+)',log)
pauses=list(zip(map(float,starts),map(float,ends)))
for w in words:
 for a,b in pauses:
  if a<=w['start']<b and w['end']>b:
   w['asr_start']=w['start'];w['start']=round(b,6);w['correction']='leading silence boundary'
# Whisper included the end of the previous utterance in Acreditamos.
for w in words:
 if w['word'].strip()=='Acreditamos':
  for a,b in pauses:
   if 0<a-w['start']<.1 and b<w['end']:
    w['asr_start']=w['start'];w['start']=round(b,6);w['correction']='leading inter-phrase silence boundary'
json.dump(words,open('analysis/words-refined.json','w'),ensure_ascii=False,indent=2)
keys={'parou':('parou',0),'pensar':('pensar',0),'tudo':('tudo',0),'manter':('manter',0),'escola':('escola',0),'segura':('segura',0),'entra':('entra',0),'somos':('somos',0),'gse':('gse',0),'grupamento':('grupamento',0),'seguranca':('segurança',0),'escolar':('escolar',0),'guarda':('guarda',0),'saoluis':('são',0),'missao':('missão',0),'muito':('muito',0),'alem':('além',0),'rondas':('rondas',0),'estamos':('estamos',0),'escolas':('escolas',0),'acompanhando':('acompanhando',0),'rotina':('rotina',0),'prevenindo':('previnindo',0),'risco':('risco',0),'fortalecendo':('fortalecendo',0),'ensina':('ensina',0),'aprende':('aprende',0),'trabalha':('trabalha',0),'educacao':('educação',0),'acreditamos':('acreditamos',0),'constroi':('constrói',0),'presenca':('presença',0),'dialogo':('diálogo',0),'respeito':('respeito',0),'proximidade':('proximidade',0),'comunidade':('comunidade',0),'move':('move',0),'trabalhar':('trabalhar',0),'cada':('cada',0),'seguras':('seguras',0),'referencia':('referência',0),'protecao':('proteção',0),'prevencao':('prevenção',0),'ambiente':('ambiente',0),'agora':('agora',0),'acompanhar':('acompanhar',0),'aqui':('aqui',0),'acoes':('ações',0),'trabalho':('trabalho',0),'dia':('dia',0),'proteger':('proteger',0),'nos':('nós',0),'gsefinal':('gse',1),'forca':('força',0),'honra':('honra',0)}
def norm(s):return re.sub(r'[^\w]','',s.lower())
cues={}
for key,(term,n) in keys.items():
 matches=[w for w in words if norm(w['word'])==term]
 cues[key]=matches[n]['start']
cues['entraInicio']=next(w['start'] for w in words if norm(w['word'])=='é')
cues['moveInicio']=next(s['start'] for s in segs if 'nos move' in s['text'])
# Exact decoded audio sample count = 2339712 at 44100 Hz.
cues['duration']=53.05469387755102
json.dump(cues,open('src/cues.json','w'),ensure_ascii=False,indent=2)
print(json.dumps(cues,ensure_ascii=False,indent=2))
