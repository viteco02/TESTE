"""Publish the approved delivery files using an isolated Git index.
Run only when delivery to this connected repository has been requested.
Existing worktree, index and local branch are not changed.
"""
import subprocess,os,tempfile,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
REPO=Path('/workspace/TESTE')
artifacts={
 'GSE_MOTION_FINAL_V2.mp4':ROOT/'out/v2/GSE_MOTION_FINAL.mp4',
 'GSE_REMOTION_PROJETO_V2.zip':ROOT/'out/v2/GSE_REMOTION_PROJETO_V2.zip'
}
def git(*args,input=None,extra=None):
 environment=os.environ.copy()
 if extra:environment.update(extra)
 return subprocess.check_output(['git','-C',str(REPO),*args],input=input,env=environment).decode().strip()
validation=json.loads((ROOT/'analysis/v2/DELIVERY_VALIDATION.json').read_text())
assert validation['full_decode']=='passed'
assert hashlib.sha256(artifacts['GSE_MOTION_FINAL_V2.mp4'].read_bytes()).hexdigest()==validation['sha256']
assert all(p.is_file() and p.stat().st_size<100*1024*1024 for p in artifacts.values())
git('fetch','origin','main')
parent=git('rev-parse','--verify','FETCH_HEAD^{commit}')
fd,index=tempfile.mkstemp(prefix='gse-v2-index-',dir='/tmp');os.close(fd);os.unlink(index)
extra={'GIT_INDEX_FILE':index}
try:
 git('read-tree',parent,extra=extra)
 data={}
 for remote,path in artifacts.items():
  assert not git('ls-tree','--name-only',parent,'--',remote),'Delivery path already exists; inspect before replacing.'
  blob=git('hash-object','-w',str(path))
  git('update-index','--add','--cacheinfo','100644',blob,remote,extra=extra)
  data[remote]={'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'git_blob':blob,'download_url':f'https://github.com/viteco02/TESTE/raw/refs/heads/main/{remote}?download=1'}
 tree=git('write-tree',extra=extra)
 commit=git('commit-tree',tree,'-p',parent,input='Adiciona versão 2 do Reels GSE com fotos da UEB Gonçalves Dias e projeto editável\n'.encode())
 changed=set(git('diff-tree','--no-commit-id','--name-only','-r',commit).splitlines())
 assert changed==set(artifacts)
 git('push','--dry-run','origin',commit+':refs/heads/main')
 git('push','origin',commit+':refs/heads/main')
 report={'commit':commit,'parent':parent,'repository':'viteco02/TESTE','artifacts':data}
 (ROOT/'analysis/v2/github-delivery.json').write_text(json.dumps(report,indent=2))
 print(json.dumps(report,indent=2))
finally:
 if os.path.exists(index):os.unlink(index)
