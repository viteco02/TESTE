# Revisão visual — versão 2

Foi renderizada uma prévia integral de 1592 quadros, em 540×960/30 fps, com a narração original completa. Foram extraídos quadros a cada segundo e examinados em duas folhas de contato. Também foram examinados quadros maiores da abertura (1.7 s), prevenção (19.25 s), aprendizagem (23.85 s) e comunidade (30.83 s).

- A abertura combina tipografia, mochila, lupa e a fotografia real da fachada.
- Escola segura reúne fachada e entrada reais com objeto de proteção.
- A apresentação institucional preserva os dois brasões originais e integra pátio e identificação reais.
- Rondas e rotina são acompanhadas por sequência de fotos, percurso e enquadramentos de observação.
- Prevenção usa a lupa em movimento sobre fotos da fachada e do pátio.
- Ensina, aprende e trabalha recebem objetos próprios e entradas nas palavras correspondentes.
- A segurança construída com a comunidade aparece como mesa de convivência, formas de diálogo e aproximação entre fotografia e objetos.
- Proteção e prevenção têm objetos distintos acompanhados do pátio real.
- A composição de redes sociais usa fotografias reais, sem inventar datas, métricas, ocorrências ou relatos de ações do GSE.
- O encerramento converge para o brasão original e Força e Honra.

A revisão encontrou o texto inferior da sequência de comunidade muito próximo ao rodapé. O texto PROXIMIDADE e a frase com a comunidade foram reposicionados antes da exportação final. Os demais textos principais nas amostras foram legíveis e os objetos não esconderam as palavras-chave.

As fotos fornecidas têm resolução nativa limitada. A montagem as apresenta como recortes fotográficos editoriais. A arquitetura e a identificação da escola não foram reconstruídas por IA, nem foram geradas fotos artificiais da escola ou de ações do GSE.

A validação final de resolução, codecs, duração, preservação dos originais e continuidade da narração é registrada separadamente em DELIVERY_VALIDATION.json após a exportação.

Na revisão do primeiro export em resolução integral, foi identificado corte na parte superior de acentos em caixa alta. A área superior das máscaras tipográficas foi ampliada sem alterar a posição dos textos, e um novo quadro de PROTEÇÃO / PREVENÇÃO foi renderizado e examinado. A correção mantém os sinais completos. O vídeo foi exportado novamente com esse ajuste antes da entrega.
