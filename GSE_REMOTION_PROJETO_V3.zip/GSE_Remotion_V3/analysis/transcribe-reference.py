import sys,json,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'python-packages'))
os.environ['HF_HOME']=str(ROOT/'models')
os.environ['HF_XET_CACHE']=str(ROOT/'models/xet-cache')
from faster_whisper import WhisperModel
m=WhisperModel('small',device='cpu',compute_type='int8',download_root=str(ROOT/'models'),cpu_threads=1)
segments,_=m.transcribe(str(ROOT/'references/Kinetic Typography Motion Design Reel.mp4'),language='en',word_timestamps=True)
r=[{'start':s.start,'end':s.end,'text':s.text,'words':[{'start':w.start,'end':w.end,'word':w.word} for w in s.words]} for s in segments]
json.dump(r,open(str(ROOT/'analysis/reference-audio-alignment.json'),'w'),indent=2)
