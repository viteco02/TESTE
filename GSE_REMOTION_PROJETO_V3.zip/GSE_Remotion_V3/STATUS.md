# GSE — versão 3 concluída

Entrega: `out/v3/GSE_MOTION_FINAL.mp4`.
1080×1920, 30 fps, H.264/yuv420p BT.709, AAC estéreo, 53.054694 segundos.
Tamanho: 24680626 bytes.

A composição principal GSE substitui a escola genérica por uma interpretação ilustrada da UEB Gonçalves Dias, baseada nas fotografias fornecidas. As fotografias não aparecem como cartões ou slideshow na versão 3. As versões históricas GSE-V1 e GSE-V2 foram preservadas.

Foram ampliadas as animações ligadas ao significado das palavras: relógio que para; lâmpada que acende; portão que abre; trajeto que ultrapassa a órbita; proteção antes do risco; construção da escola em camadas; cadeiras que cedem espaço e depois se aproximam; conjunto que avança em MOVE; acompanhamento no celular.

Prévia integral, revisão de 24 momentos, ajustes de posição e render final concluídos. A exportação final passou na decodificação integral, codecs, duração, continuidade da voz e integridade dos originais. Resultados em `analysis/v3/DELIVERY_VALIDATION.json`; revisão visual em `analysis/v3/VISUAL_REVIEW.md`.

Projeto editável: `src/film-v3.tsx`, `src/visuals-v3.tsx` e `src/motion.tsx`. Os novos assets ficam em `public/assets/v3/`.

Nomes dos artefatos públicos: `GSE_MOTION_FINAL_V3.mp4` e `GSE_REMOTION_PROJETO_V3.zip`. As entregas V1 e V2 não são sobrescritas.
