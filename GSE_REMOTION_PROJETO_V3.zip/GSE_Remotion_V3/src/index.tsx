import React from 'react';
import {registerRoot,Composition} from 'remotion';
import {GSEFilm} from './film';
import {GSEFilmV3} from './film-v3';
import {GSEFilmV2} from './film-v2';
import {AssetStudy} from './study';
import cues from './cues.json';
const Root:React.FC=()=> <><Composition id="GSE" component={GSEFilmV3} width={1080} height={1920} fps={30} durationInFrames={Math.ceil(cues.duration*30)}/><Composition id="GSE-V2" component={GSEFilmV2} width={1080} height={1920} fps={30} durationInFrames={Math.ceil(cues.duration*30)}/><Composition id="GSE-V1" component={GSEFilm} width={1080} height={1920} fps={30} durationInFrames={Math.ceil(cues.duration*30)}/><Composition id="AssetStudy" component={AssetStudy} width={1080} height={1920} fps={30} durationInFrames={180}/></>;
registerRoot(Root);
