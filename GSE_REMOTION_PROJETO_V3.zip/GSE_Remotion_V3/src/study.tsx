import React from 'react';
import {AbsoluteFill,Img,staticFile,useCurrentFrame,interpolate,spring,useVideoConfig,Easing} from 'remotion';
const navy='#102743',gold='#D6A545';
export const fonts=`@font-face{font-family:Anton;src:url('${staticFile('assets/Anton-Regular.ttf')}')}@font-face{font-family:Instrument;src:url('${staticFile('assets/InstrumentSerif-Italic.ttf')}')}@font-face{font-family:Space;src:url('${staticFile('assets/SpaceGrotesk.ttf')}')}`;
export const Reveal:React.FC<{text:string;start:number;size?:number;serif?:boolean;style?:React.CSSProperties}>=({text,start,size=180,serif=false,style})=>{
 const f=useCurrentFrame(); const {fps}=useVideoConfig(); const p=spring({frame:f-start,fps,config:{damping:22,stiffness:120}});
 return <div style={{overflow:'hidden',paddingBottom:15,...style}}><div style={{fontFamily:serif?'Instrument':'Anton',fontSize:size,lineHeight:1.06,transform:`translateY(${(1-p)*115}%) rotate(${(1-p)*4}deg)`,letterSpacing:serif?-3:-2}}>{text}</div></div>
};
export const Grid:React.FC=()=> <AbsoluteFill style={{backgroundColor:'#F5F7F8',backgroundImage:'linear-gradient(#10274308 1px, transparent 1px),linear-gradient(90deg,#10274308 1px,transparent 1px)',backgroundSize:'72px 72px'}}/>;
export const AssetStudy:React.FC=()=>{
 const f=useCurrentFrame();const{fps}=useVideoConfig();
 const reveal=spring({frame:f-102,fps,config:{damping:23}});
 const rise=interpolate(f,[80,106],[0,-700],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.inOut(Easing.cubic)});
 return <AbsoluteFill style={{color:navy,fontFamily:'Space'}}><style>{fonts}</style><Grid/>
 <div style={{position:'absolute',top:114,left:84,right:84,display:'flex',justifyContent:'space-between',fontSize:22,letterSpacing:4}}><span>GSE / SÃO LUÍS</span><span>01</span></div>
 <div style={{position:'absolute',left:84,top:280,transform:`translateY(${rise}px)`}}><Reveal text="uma escola" start={0} serif size={140}/><Reveal text="SEGURA" start={12} size={244}/><div style={{height:8,width:interpolate(f,[20,45],[0,860],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}),background:gold,marginTop:22}}/></div>
 <Img src={staticFile('assets/escola-editorial.png')} style={{position:'absolute',width:1120,left:-20,top:680,transform:`translateY(${rise*.8}px) rotate(${Math.sin(f/40)*1.5}deg) scale(${1+f/1800})`,mixBlendMode:'multiply',opacity:1-reveal}}/>
 <div style={{position:'absolute',inset:0,background:navy,clipPath:`circle(${reveal*150}% at 50% 62%)`}}/>
 <div style={{position:'absolute',left:84,top:260,color:'#F5F7F8',opacity:reveal}}><Reveal text="É aí que" start={105} serif size={150}/><Reveal text="a gente entra!" start={112} size={124}/></div>
 <div style={{position:'absolute',width:830,height:830,borderRadius:'50%',background:'#F5F7F8',left:125,top:660,opacity:reveal,transform:`scale(${.6+reveal*.4})`,boxShadow:'0 30px 70px #0002'}}/><Img src={staticFile('assets/gse-original.png')} style={{position:'absolute',width:790,left:145,top:680,transform:`translateY(${(1-reveal)*400}px) scale(${.6+reveal*.4}) rotate(${(1-reveal)*-20}deg)`,opacity:reveal,filter:'drop-shadow(0 30px 30px #0003)'}}/>
 <div style={{position:'absolute',bottom:130,left:84,right:84,borderTop:`2px solid ${gold}`,paddingTop:22,fontSize:23,letterSpacing:3,color:reveal>.5?'#F5F7F8':navy}}>GRUPAMENTO DE SEGURANÇA ESCOLAR</div>
 </AbsoluteFill>
};
