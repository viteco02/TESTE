import React,{useState,useEffect} from 'react';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame,delayRender,continueRender,cancelRender,Img} from 'remotion';
import Q from './cues.json';
import {C,F,fontCSS,Place,Type,Rule,Orbit,Route,Book,Badge,Shot,ramp,snap,useTime} from './motion';
import {SchoolUEB,Object3D,Prop,Clock,Bulb,Dome,Gate,CommunityTable} from './visuals-v3';

const Opening3:React.FC=()=>{return <>
 <Shot from={0} to={3.28} chapter="GRUPAMENTO DE SEGURANÇA ESCOLAR" index={1} transition="none">
 <Place y={270}><Type text="Você já" at={0} size={154} face="serif" instant/></Place>
 <Place y={470}><Type text="PAROU" at={Q.parou} size={272} mode="letters"/></Place>
 <Place y={790}><Type text="pra pensar?" at={Q.pensar} size={142} face="serif"/></Place>
 <Bulb at={Q.pensar-.1} on={Q.pensar} x={745} y={745} w={270}/>
 <Clock at={0} stop={Q.parou} x={750} y={1010} w={265}/>
 <SchoolUEB at={0} x={75} y={1110} w={930}/>
 <Place y={995}><Type text="em tudo o que acontece" at={Q.tudo} size={39} face="sans"/></Place>
 <Route at={Q.pensar} path="M -30 1590 Q 340 1770 820 1630" width={5}/>
 </Shot>
 <Shot from={3.28} to={Q.entraInicio} chapter="UEB GONÇALVES DIAS / SÃO LUÍS" index={2} transition="slant">
 <Place y={250}><Type text="ESCOLA" at={Q.escola-.08} size={224} mode="turn"/></Place>
 <Place x={160} y={510}><Type text="SEGURA" at={Q.segura} size={227} mode="stretch"/></Place>
 <Dome at={Q.segura} x={65} y={800} w={950}/>
 <SchoolUEB at={3.2} x={30} y={1030} w={1020}/>
 <Object3D kind="shield" at={Q.segura} x={730} y={1360} w={255} rotate={5}/>
 </Shot>
 </>};
const Identity3:React.FC=()=>{const t=useTime(),enter=ramp(t,Q.entra,Q.entra+.65);return <>
 <Shot from={Q.entraInicio} to={Q.somos} chapter="GRUPAMENTO DE SEGURANÇA ESCOLAR" index={3} bg={C.navy} dark transition="iris">
 <Place y={260}><Type text="É aí que" at={Q.entraInicio} size={176} face="serif" color={C.ice}/></Place>
 <Place y={470}><Type text="a gente" at={5.15} size={126} face="sans" color={C.ice}/></Place>
 <Place y={660}><Type text="ENTRA!" at={Q.entra} size={249} mode="stretch" color={C.ice}/></Place>
 <div style={{position:'absolute',inset:0,transform:`translateY(${enter*175}px) scale(${.55+enter*.45})`,transformOrigin:'540px 1430px'}}><Badge at={Q.entraInicio} x={420} y={1300} w={240} plate rotate={false}/></div>
 <Gate at={Q.entraInicio} open={Q.entra} y={990} w={900}/>
 <Route at={Q.entra} path="M 540 1635 L 540 1740" width={5}/>
 </Shot>
 <Shot from={Q.somos} to={Q.guarda} chapter="GRUPAMENTO DE SEGURANÇA ESCOLAR" index={4} transition="paper">
 <Place y={235}><Type text="Somos o" at={Q.somos} size={142} face="serif"/></Place>
 <Place y={385}><Type text="GSE" at={Q.gse} size={325} mode="letters"/></Place>
 <Orbit at={Q.gse} x={70} y={650} size={940} tilt={40}/>
 <Badge at={Q.gse} x={260} y={750} w={560} plate/>
 <Place y={1455}><Type text="Grupamento de" at={Q.grupamento} size={67} face="sans"/></Place>
 <Place y={1550}><Type text="Segurança Escolar" at={Q.seguranca} size={94} face="serif"/></Place>
 <Place y={1700}><Rule at={Q.escolar} w={900}/></Place>
 </Shot>
 <Shot from={Q.guarda} to={11.98} chapter="GUARDA MUNICIPAL DE SÃO LUÍS" index={5} transition="hinge">
 <Place y={240}><Type text="Guarda" at={Q.guarda} size={154} face="serif"/></Place>
 <Place y={425}><Type text="MUNICIPAL" at={Q.guarda+.12} size={163} mode="spread"/></Place>
 <Badge at={Q.guarda-.12} kind="guarda" x={295} y={680} w={465}/>
 <Badge at={Q.guarda+.2} x={735} y={1080} w={220} plate/>
 <Route at={Q.saoluis-.3} path="M 80 1450 Q 560 1550 1000 1380"/>
 <Place y={1535}><Type text="de São Luís." at={Q.saoluis} size={132} face="serif"/></Place>
 </Shot>
 </>};
const Mission3:React.FC=()=>{const t=useTime(),burst=ramp(t,14.72,15.45),scan=ramp(t,Q.prevenindo,Q.prevenindo+1),risk=ramp(t,Q.risco,Q.risco+.3);return <>
 <Shot from={11.98} to={Q.estamos} chapter="NOSSA MISSÃO" index={6} transition="slant">
 <Place y={260}><Type text="nossa missão" at={Q.missao-.16} size={140} face="serif"/></Place>
 <Place y={460}><Type text="MUITO" at={Q.muito} size={218} mode="spread"/></Place>
 <Place x={430} y={730}><Type text="ALÉM" at={Q.alem} size={212} mode="stretch" color={C.blue}/></Place>
 <Object3D kind="lens" at={Q.alem} x={65} y={730} w={290} rotate={-15}/>
 <Orbit at={Q.missao} x={120} y={990} size={840} tilt={72}/>
 <SchoolUEB at={Q.missao} x={130} y={1010} w={820}/>
 <Route at={Q.alem} path="M 540 1375 C 900 1440 1030 1040 720 1000 C 350 910 100 1160 230 1370 Q 520 1780 1160 1500"/>
 <Place y={1490} style={{display:'flex'}}>{[...'RONDAS'].map((c,i)=><div key={i} style={{transform:`translate(${(i-2.5)*burst*150}px,${burst*(i%2?-200:220)}px) rotate(${burst*(i-2)*17}deg)`,opacity:1-burst*.8}}><Type text={c} at={Q.rondas+i*.02} size={202} mode="turn"/></div>)}</Place>
 </Shot>
 <Shot from={Q.estamos} to={Q.fortalecendo} chapter="ACOMPANHAMENTO / PREVENÇÃO" index={7} transition="iris">
 <Place y={245}>{t<Q.acompanhando?<><Type text="Estamos nas" at={Q.estamos} size={122} face="serif"/><Type text="ESCOLAS" at={Q.escolas} size={208} mode="letters"/></>:<><Type text="acompanhando" at={Q.acompanhando} size={103} face="sans"/><Type text="a rotina" at={Q.rotina-.1} size={154} face="serif"/></>}</Place>
 <Clock at={Q.rotina} x={70} y={665} w={230}/>
 <Prop kind="bell" at={Q.rotina} x={770} y={675} w={235} rotation={Math.sin(Math.max(0,t-Q.rotina)*19)*14*Math.exp(-Math.max(0,t-Q.rotina)*2)}/>
 <SchoolUEB at={Q.estamos-.1} x={45} y={865} w={990}/>
 <Route at={Q.acompanhando} path="M 100 1370 Q 200 1570 680 1470 T 1000 1200" width={5}/>
 <Object3D kind="lens" at={Q.prevenindo} x={750-scan*220} y={920+scan*70} w={300} rotate={-22}/>
 <Object3D kind="shield" at={Q.prevenindo} x={350} y={1270} w={260}/>
 <Place y={1480}><Type text="PREVENINDO" at={Q.prevenindo} size={150} mode="letters"/></Place>
 <Place y={1655}><Type text="situações de" at={Q.risco-.6} size={66} face="serif"/></Place>
 <div style={{position:'absolute',left:610,top:1640,height:110,width:4,background:C.gold,opacity:ramp(t,Q.prevenindo,Q.prevenindo+.2)}}/>
 <Place x={1080-risk*430} y={1645}><Type text="RISCO" at={Q.risco} size={93} mode="turn" color={C.blue}/></Place>
 </Shot>
 </>};
const Learning3:React.FC=()=>{const t=useTime(),strong=ramp(t,Q.fortalecendo,Q.fortalecendo+.7);return <>
 <Shot from={Q.fortalecendo} to={21.82} chapter="FORTALECENDO A SEGURANÇA" index={8} bg={C.blue} dark transition="paper">
 <Place y={270}><Type text="fortalecendo" at={Q.fortalecendo} size={130} face="serif" color={C.ice}/></Place>
 <Place y={480}><Type text="a segurança" at={20.9} size={131} face="sans" color={C.ice}/></Place>
 <Orbit at={Q.fortalecendo} x={100} y={870} size={880} tilt={60} color={C.ice}/>
 <Orbit at={Q.fortalecendo+.15} x={50} y={820} size={980} tilt={60}/>
 <SchoolUEB at={Q.fortalecendo-.1} x={75} y={1040} w={930} scale={.94+strong*.06}/>
 <Object3D kind="shield" at={21.06} x={375} y={710} w={300}/>
 </Shot>
 <Shot from={21.82} to={Q.acreditamos} chapter="QUEM ENSINA, APRENDE E TRABALHA" index={9} transition="wipe">
 <Place y={235}><Type text="de quem" at={21.82} size={100} face="serif"/></Place>
 <Place y={410}><Type text="ENSINA" at={Q.ensina} size={205} mode="turn"/></Place>
 <Object3D kind="bag" at={Q.ensina} x={675} y={630} w={315} rotate={8}/>
 <Book at={Q.ensina} x={80} y={690} w={610} rotation={-8}/>
 <Bulb at={Q.aprende-.1} on={Q.aprende} x={700} y={1050} w={270}/>
 <Place y={1110}><Type text="aprende" at={Q.aprende} size={180} face="serif" color={C.blue}/></Place>
 <Place y={1400}><Type text="TRABALHA" at={Q.trabalha} size={164} mode="letters"/></Place>
 <Badge at={Q.trabalha} x={775} y={1485} w={170}/>
 <Place x={225} y={1640}><Type text="pela educação." at={Q.educacao-.15} size={98} face="serif"/></Place>
 <Route at={Q.ensina} path="M 55 710 C 350 700 1000 730 1010 1000 Q 1000 1240 80 1320" width={4}/>
 </Shot>
 <Shot from={Q.acreditamos} to={Q.presenca} chapter="SEGURANÇA TAMBÉM SE CONSTRÓI" index={10} transition="slant">
 <Place y={250}><Type text="Acreditamos" at={Q.acreditamos} size={131} face="serif"/></Place>
 <Place y={440}><Type text="SEGURANÇA" at={25.8} size={170} mode="letters"/></Place>
 <Place y={760}><Type text="também se" at={26.22} size={112} face="serif"/></Place>
 <Place x={245} y={915}><Type text="CONSTRÓI" at={Q.constroi} size={172} mode="letters" color={C.blue}/></Place>
 <Place x={80} y={1680}><Rule at={Q.constroi-.15} w={920}/></Place>
 <SchoolUEB at={Q.acreditamos} x={65} y={1100} w={950} build={Q.constroi-.18}/>
 </Shot>
 </>};
const Community3:React.FC=()=>{const t=useTime(),near=ramp(t,Q.proximidade,Q.proximidade+.65);return <Shot from={Q.presenca} to={Q.moveInicio} chapter="COM A COMUNIDADE" index={11} transition="wipe">
 <Place y={270}><Type text="PRESENÇA" at={Q.presenca} size={184} mode="spread"/></Place>
 <Place x={420} y={520}><Type text="diálogo" at={Q.dialogo} size={180} face="serif"/></Place>
 <SchoolUEB at={Q.presenca} x={25+near*110} y={740} w={440} scale={1+near*.1}/>
 <Object3D kind="dialogue" at={Q.dialogo} x={625-near*100} y={710} w={345} rotate={Math.sin(Math.max(0,t-Q.dialogo)*7)*4}/>
 <CommunityTable at={Q.presenca} respect={Q.respeito} near={Q.proximidade}/>
 <Place y={1400}><Type text="RESPEITO" at={Q.respeito} size={153} mode="stretch"/></Place>
 <Place x={84+near*14} y={1555}><Type text="PROXIMIDADE" at={Q.proximidade} size={132} color={C.blue} style={{letterSpacing:10-near*11}}/></Place>
 <Place x={350} y={1708}><Type text="com a comunidade." at={Q.comunidade-.1} size={40} face="serif"/></Place>
 </Shot>};
const Purpose3:React.FC=()=>{const t=useTime(),move=ramp(t,Q.move,Q.trabalhar),secure=ramp(t,Q.seguras,Q.seguras+.7);return <>
 <Shot from={Q.moveInicio} to={Q.trabalhar} chapter="É ISSO QUE NOS MOVE" index={12} bg={C.navy} dark transition="hinge">
 <Place y={320}><Type text="É isso que" at={Q.moveInicio} size={150} face="serif" color={C.ice}/></Place>
 <Place x={570} y={550}><Type text="nos" at={32.58} size={165} face="serif" color={C.ice}/></Place>
 <div style={{position:'absolute',inset:0,transform:`translateX(${move*130}px) rotate(${-move*3}deg)`}}>
 <Place y={770}><Type text="MOVE" at={Q.move} size={340} mode="stretch" color={C.ice}/></Place>
 <SchoolUEB at={Q.moveInicio} x={-110} y={1240} w={800}/>
 <Object3D kind="bag" at={Q.move} x={690} y={1330} w={260} rotate={10}/></div>
 <Route at={Q.move} path="M -20 1720 Q 600 1730 1140 1240"/>
 </Shot>
 <Shot from={Q.trabalhar} to={Q.protecao} chapter="ESCOLAS CADA VEZ MAIS SEGURAS" index={13} transition="slant">
 <Place y={250}>{t<Q.cada?<><Type text="trabalhar por" at={Q.trabalhar} size={138} face="serif"/><Type text="ESCOLAS" at={34.04} size={220} mode="letters"/></>:<><Type text="cada vez mais" at={Q.cada} size={138} face="serif"/><Type text="SEGURAS" at={Q.seguras} size={220} mode="stretch"/></>}</Place>
 <Dome at={Q.seguras} x={65} y={780} w={950} strength={1+secure}/>
 <SchoolUEB at={Q.trabalhar-.1} x={40} y={1030} w={1000}/>
 <Object3D kind="shield" at={Q.seguras} x={730} y={1300} w={250}/>
 <Place y={1600}><Type text="ser referência" at={Q.referencia-.15} size={112} face="serif" color={C.blue}/></Place>
 </Shot>
 <Shot from={Q.protecao} to={Q.agora} chapter="NO AMBIENTE ESCOLAR" index={14} transition="paper">
 <Place y={270}><Type text="PROTEÇÃO" at={Q.protecao} size={201} mode="turn"/></Place>
 <Place x={700} y={505}><Type text="e" at={37.68} size={130} face="serif" color={C.gold}/></Place>
 <Place y={680}><Type text="PREVENÇÃO" at={Q.prevencao} size={179} mode="spread" color={C.blue}/></Place>
 <Dome at={Q.protecao} x={60} y={970} w={950}/>
 <SchoolUEB at={Q.protecao} x={100} y={1150} w={880}/>
 <Object3D kind="shield" at={Q.protecao} x={50} y={1020} w={280} rotate={-8}/>
 <Object3D kind="lens" at={Q.prevencao} x={750-ramp(t,Q.ambiente,Q.ambiente+.7)*95} y={1400} w={310} rotate={-20}/>
 </Shot>
 </>};
const Social3:React.FC=()=>{const t=useTime(),f=useCurrentFrame(),p=snap(f,Q.agora+.15),lift=ramp(t,47.75,48.5),follow=ramp(t,Q.acompanhar,Q.acompanhar+1.3);return <Shot from={Q.agora} to={Q.nos} chapter="AÇÕES / TRABALHO / DIA A DIA" index={15} transition="iris">
 {t<43.92?<><Place y={250}><Type text="Agora," at={Q.agora} size={166} face="serif"/></Place><Place y={455}><Type text="você vai acompanhar" at={Q.acompanhar-.65} size={82} face="sans"/></Place><Place x={485} y={575}><Type text="por aqui." at={Q.aqui-.2} size={116} face="serif" color={C.blue}/></Place></>:t<45.12?<><Place y={250}><Type text="Nossas" at={43.92} size={156} face="serif"/></Place><Place y={445}><Type text="AÇÕES" at={Q.acoes} size={227} mode="letters"/></Place></>:t<46.16?<><Place y={250}><Type text="nosso" at={45.12} size={148} face="serif"/></Place><Place y={435}><Type text="TRABALHO" at={Q.trabalho} size={174} mode="spread"/></Place></>:<><Place y={250}><Type text="o dia a dia" at={Q.dia} size={156} face="serif"/></Place><Place y={460}><Type text="quem está presente" at={47.38} size={72} face="sans" color={C.blue}/></Place></>}
 <Orbit at={Q.acompanhar} x={-100} y={650} size={1280} tilt={72}/>
 <div style={{position:'absolute',left:245,top:760+(1-p)*190-lift*200,width:590,height:880,border:`10px solid ${C.navy}`,borderRadius:58,background:C.ice,overflow:'hidden',boxShadow:'20px 35px 50px #10274324',opacity:p,transform:`rotate(${-5+follow*5}deg) scale(${1-lift*.12})`,transformOrigin:'50% 20%'}}>
 <div style={{position:'absolute',left:200,top:18,width:170,height:18,borderRadius:20,background:C.navy}}/>
 <div style={{position:'absolute',left:30,top:75,display:'flex',alignItems:'center',gap:18,fontFamily:F.sans,fontSize:30,fontWeight:600}}><Img src={staticFile('assets/gse-original.png')} style={{width:65}}/>GSE / SÃO LUÍS</div>
 <SchoolUEB at={Q.agora+.2} x={-40} y={200} w={650}/>
 <div style={{position:'absolute',left:40,top:660,width:490,height:5,background:C.navy+'20'}}><div style={{width:`${follow*100}%`,height:5,background:C.gold}}/><div style={{position:'absolute',left:follow*475,top:-10,width:24,height:24,borderRadius:'50%',background:C.gold}}/></div>
 <Place x={38} y={725}><Type text={t<Q.trabalho?'AÇÕES':t<Q.dia?'TRABALHO':'DIA A DIA'} at={Q.agora+.2} size={65}/></Place>
 </div>
 {t<Q.trabalho?<Object3D kind="lens" at={Q.acoes} x={725} y={1180-lift*200} w={300} rotate={-15}/>:t<Q.dia?<Object3D kind="shield" at={Q.trabalho} x={710} y={1170-lift*200} w={290}/>:<Clock at={Q.dia} x={710} y={1170-lift*200} w={290}/>}
 <Place y={1440}><Type text="na missão de" at={48.02} size={96} face="serif"/><Type text="PROTEGER" at={Q.proteger} size={183} mode="stretch"/></Place>
 </Shot>};
const Ending3:React.FC=()=> <Shot from={Q.nos} to={Q.duration} chapter="GRUPAMENTO DE SEGURANÇA ESCOLAR" index={16} transition="iris">
 <Badge at={Q.nos} kind="guarda" x={875} y={210} w={95} rotate={false}/>
 <Place y={240}><Type text="Nós somos o" at={Q.nos} size={134} face="serif"/></Place>
 <Place y={410}><Type text="GSE" at={Q.gsefinal} size={320} mode="letters"/></Place>
 <Orbit at={Q.nos} x={65} y={725} size={950} tilt={35}/>
 <Badge at={Q.nos-.15} x={250} y={785} w={580}/>
 <Place y={1400}><Type text="Força" at={Q.forca} size={145} face="serif"/></Place><Place x={430} y={1400}><Type text="e" at={52.18} size={145} face="serif"/></Place>
 <Place x={400} y={1530}><Type text="HONRA" at={Q.honra} size={164} mode="stretch"/></Place>
 <Place y={1750}><Rule at={Q.forca} w={910}/></Place>
 </Shot>;
export const GSEFilmV3:React.FC=()=>{
 const [handle]=useState(()=>delayRender('Loading editorial fonts'));
 useEffect(()=>{Promise.all([document.fonts.load('140px Instrument','Força e Honra'),document.fonts.load('180px Anton','SEGURANÇA PREVENÇÃO'),document.fonts.load('600 80px Space','ações presença')]).then(()=>continueRender(handle)).catch(cancelRender)},[handle]);
 return <AbsoluteFill style={{background:C.ice,fontFamily:F.sans}}><style>{fontCSS}</style><Audio src={staticFile('assets/narracao-original.mp3')}/><Opening3/><Identity3/><Mission3/><Learning3/><Community3/><Purpose3/><Social3/><Ending3/></AbsoluteFill>
};
