import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, spring, staticFile, useCurrentFrame} from 'remotion';
export const C={ice:'#F5F7F8',navy:'#102743',gold:'#D6A545',blue:'#2368AB',graphite:'#383838'};
export const F={display:'Anton',serif:'Instrument',sans:'Space'};
export const fontCSS=`@font-face{font-family:Anton;src:url('${staticFile('assets/Anton-Regular.ttf')}')}@font-face{font-family:Instrument;src:url('${staticFile('assets/InstrumentSerif-Italic.ttf')}')}@font-face{font-family:Space;src:url('${staticFile('assets/SpaceGrotesk.ttf')}');font-weight:300 700}*{box-sizing:border-box}`;
export const ramp=(t:number,a:number,b:number)=>interpolate(t,[a,b],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:Easing.inOut(Easing.cubic)});
export const snap=(f:number,at:number,delay=0)=>spring({frame:f-at*30-delay,fps:30,config:{damping:24,stiffness:170,mass:.8}});
export const useTime=()=>useCurrentFrame()/30;
export const Place:React.FC<React.PropsWithChildren<{x?:number;y?:number;w?:number;style?:React.CSSProperties}>>=({x=84,y=0,w,style,children})=><div style={{position:'absolute',left:x,top:y,width:w,...style}}>{children}</div>;
export const Type:React.FC<{text:string;at:number;size?:number;face?:keyof typeof F;mode?:'rise'|'letters'|'spread'|'turn'|'stretch';color?:string;outline?:boolean;style?:React.CSSProperties;instant?:boolean}>=({text,at,size=140,face='display',mode='rise',color=C.navy,outline=false,style,instant=false})=>{
 const f=useCurrentFrame(); const p=instant?1:snap(f,at);
 const visible=instant||f>=at*30;
 const base:React.CSSProperties={visibility:visible?'visible':'hidden',fontFamily:F[face],fontSize:size,lineHeight:1.06,letterSpacing:face==='sans'?-2:face==='serif'?-3:-1,color:outline?'transparent':color,WebkitTextStroke:outline?`3.5px ${color}`:undefined,fontWeight:face==='sans'?600:400,whiteSpace:'pre',...style};
 if(mode==='letters'||mode==='turn')return <div style={{...base,display:'flex',overflow:'hidden',paddingTop:size*.2,marginTop:-size*.2,paddingBottom:size*.12}}>{[...text].map((l,i)=>{const v=instant?1:snap(f,at,Math.min(i*1.3,10));return <span key={i} style={{display:'inline-block',whiteSpace:'pre',transform:`translateY(${(1-v)*115}%) rotate(${(1-v)*(mode==='turn'?(i%2?30:-30):0)}deg)`,filter:v<.97?`blur(${(1-v)*5}px)`:undefined}}>{l}</span>})}</div>;
 return <div style={{overflow:'hidden',paddingTop:size*.2,marginTop:-size*.2,paddingBottom:size*.12}}><div style={{...base,transformOrigin:'left bottom',transform:`translateY(${(1-p)*112}%) scale(${mode==='stretch'?.5+.5*p:1},${mode==='stretch'?1.7-.7*p:1}) rotate(${0}deg)`,letterSpacing:mode==='spread'?`${(1-p)*32-2}px`:base.letterSpacing,filter:p<.97?`blur(${(1-p)*3}px)`:undefined}}>{text}</div></div>
};
export const Rule:React.FC<{at:number;w?:number;color?:string;vertical?:boolean}>=({at,w=900,color=C.gold,vertical=false})=>{
 const t=useTime();const p=ramp(t,at,at+.5);return <div style={{width:vertical?5:w*p,height:vertical?w*p:5,background:color}}/>;
};
export const Orbit:React.FC<{x?:number;y?:number;size?:number;at:number;color?:string;tilt?:number}>=({x=85,y=650,size=900,at,color=C.gold,tilt=65})=>{
 const t=useTime(); const p=ramp(t,at,at+.7);return <div style={{position:'absolute',left:x,top:y,width:size,height:size,border:`3px solid ${color}`,borderRadius:'50%',transform:`perspective(1200px) rotateX(${tilt}deg) rotateZ(${t*13}deg) scale(${.6+.4*p})`,opacity:p}}><div style={{position:'absolute',width:23,height:23,borderRadius:'50%',background:color,left:'50%',top:-12,boxShadow:`0 0 0 11px ${color}16`}}/></div>
};
export const Route:React.FC<{at:number;path?:string;color?:string;width?:number}>=({at,path='M -60 1500 C 400 1650, 1200 1050, 680 910 S 240 470, 1150 340',color=C.gold,width=7})=>{
 const t=useTime();const p=ramp(t,at,at+1.3);return <svg viewBox="0 0 1080 1920" style={{position:'absolute',inset:0,width:'100%',height:'100%',pointerEvents:'none'}}><path d={path} fill="none" stroke={color} strokeWidth={width} pathLength={1} strokeDasharray={1} strokeDashoffset={1-p}/></svg>
};
export const School:React.FC<{at:number;x?:number;y?:number;w?:number;rotation?:number;camera?:number}>=({at,x=-25,y=700,w=1130,rotation=0,camera=1})=>{
 const f=useCurrentFrame(),t=f/30,p=snap(f,at);return <Img src={staticFile('assets/escola-editorial.png')} style={{position:'absolute',left:x,top:y,width:w,transformOrigin:'50% 65%',transform:`translateY(${(1-p)*170+Math.sin((t-at)*1.3)*9}px) rotate(${rotation+Math.sin((t-at)*.6)*.8}deg) scale(${camera*(.96+.04*p)})`,opacity:p,mixBlendMode:'multiply',maskImage:'linear-gradient(to bottom,transparent 0%,black 13%,black 86%,transparent 100%)'}}/>;
};
export const Book:React.FC<{at:number;x?:number;y?:number;w?:number;rotation?:number}>=({at,x=25,y=760,w=1030,rotation=0})=>{
 const f=useCurrentFrame(),t=f/30,p=snap(f,at);return <Img src={staticFile('assets/comunidade-editorial.png')} style={{position:'absolute',left:x,top:y,width:w,transform:`translateY(${(1-p)*220+Math.sin((t-at)*1.6)*14}px) rotate(${rotation+(1-p)*-12+Math.sin((t-at)*.7)*1.2}deg) scale(${.85+.15*p})`,opacity:p,filter:'drop-shadow(0 25px 24px #10274312)'}}/>;
};
export const Badge:React.FC<{at:number;kind?:'gse'|'guarda';x?:number;y?:number;w?:number;plate?:boolean;rotate?:boolean}>=({at,kind='gse',x=190,y=720,w=700,plate=false,rotate=true})=>{
 const f=useCurrentFrame(),p=snap(f,at),h=kind==='gse'?w:w*3817/3375;return <div style={{position:'absolute',left:x,top:y,width:w,height:h,transform:`translateY(${(1-p)*180}px) scale(${.6+p*.4}) rotate(${rotate?(1-p)*-16:0}deg)`,opacity:p}}>{plate&&<div style={{position:'absolute',inset:-25,background:C.ice,borderRadius:'50%',boxShadow:'0 22px 60px #10274312'}}/>}<Img src={staticFile(`assets/${kind==='gse'?'gse':'guarda'}-original.png`)} style={{position:'relative',width:'100%',height:'100%',objectFit:'contain'}}/></div>
};
type Transition='wipe'|'iris'|'slant'|'paper'|'hinge'|'none';
export const Shot:React.FC<React.PropsWithChildren<{from:number;to:number;transition?:Transition;bg?:string;dark?:boolean;chapter:string;index:number}>>=({from,to,transition='wipe',bg=C.ice,dark=false,chapter,index,children})=>{
 const t=useTime(),f=useCurrentFrame();if(t<from-.28||t>to+.35)return null;
 const p=from===0?1:ramp(t,from-.23,from+.12);
 const s:React.CSSProperties={backgroundColor:bg,overflow:'hidden',color:dark?C.ice:C.navy};
 if(transition==='wipe')s.clipPath=`inset(${100*(1-p)}% 0 0 0)`;
 if(transition==='iris')s.clipPath=`circle(${p*145}% at 62% 60%)`;
 if(transition==='slant')s.clipPath=`polygon(0 0,${p*145}% 0,${p*145-45}% 100%,0 100%)`;
 if(transition==='paper')s.transform=`translateY(${(1-p)*1920}px) rotate(${(1-p)*-9}deg)`;
 if(transition==='hinge'){s.transform=`perspective(2000px) translateX(${(1-p)*110}%) rotateY(${(1-p)*-35}deg)`;s.transformOrigin='right center';}
 return <AbsoluteFill style={s}><AbsoluteFill style={{opacity:dark?.065:.6,backgroundImage:`linear-gradient(${dark?C.ice+'55':C.navy+'10'} 1px,transparent 1px),linear-gradient(90deg,${dark?C.ice+'55':C.navy+'10'} 1px,transparent 1px)`,backgroundSize:'72px 72px',transform:`translateY(${(f*.09)%72}px)`}}/>
 <div style={{position:'absolute',left:80,right:80,top:110,display:'flex',justifyContent:'space-between',fontFamily:F.sans,fontSize:22,letterSpacing:3.2,color:dark?C.ice:C.navy,zIndex:5}}><span>GSE / SÃO LUÍS</span><span>{String(index).padStart(2,'0')}</span></div>
 {children}
 <div style={{position:'absolute',left:84,right:84,bottom:112,borderTop:`1px solid ${dark?'#ffffff44':'#10274333'}`,paddingTop:19,fontFamily:F.sans,fontSize:20,letterSpacing:3,color:dark?C.ice:C.navy,zIndex:5}}>{chapter}</div>
 </AbsoluteFill>
};
