import React from 'react';
import {Img,staticFile,useCurrentFrame} from 'remotion';
import {C,F,ramp,snap,useTime} from './motion';

export type SchoolView='facade'|'front'|'courtyard'|'sign';
const photos:Record<SchoolView,{file:string;size:[number,number];crop:[number,number,number,number]}>= {
 facade:{file:'fachada.jpg',size:[495,619],crop:[0,.105,1,.79]},
 front:{file:'fachada-patio.jpg',size:[495,619],crop:[0,.025,1,.465]},
 courtyard:{file:'fachada-patio.jpg',size:[495,619],crop:[0,.505,1,.35]},
 sign:{file:'entrada.jpg',size:[416,738],crop:[0,.11,1,.345]}
};
/** Original photographs are preserved. Cropping, camera and paper edges are rendered externally. */
export const RealPhoto:React.FC<{view:SchoolView;x:number;y:number;w:number;h:number;at:number;rotate?:number;label?:boolean;bare?:boolean;opacity?:number;scale?:number}>=({view,x,y,w,h,at,rotate=0,label=false,bare=false,opacity=1,scale=1})=>{
 const f=useCurrentFrame(),t=f/30,p=at===0?1:snap(f,at),data=photos[view],edge=bare?0:12;
 const iw=w-2*edge,ih=h-2*edge-(label?44:0),[nw,nh]=data.size,[cx,cy,cw,ch]=data.crop;
 const fit=Math.max(iw/(nw*cw),ih/(nh*ch));
 const left=(iw-nw*cw*fit)/2-nw*cx*fit,top=(ih-nh*ch*fit)/2-nh*cy*fit;
 return <div style={{position:'absolute',left:x,top:y,width:w,height:h,background:bare?'transparent':'#fff',padding:edge,boxShadow:bare?undefined:'0 22px 46px #10274324',transformOrigin:'50% 60%',transform:`perspective(1800px) translateY(${(1-p)*140}px) rotateY(${(1-p)*-14}deg) rotate(${rotate+(1-p)*7}deg) scale(${scale*(.88+.12*p)})`,opacity:p*opacity}}>
 <div style={{position:'relative',width:iw,height:ih,overflow:'hidden',clipPath:`inset(${(1-p)*100}% 0 0 0)`}}><Img src={staticFile('assets/real-school/'+data.file)} style={{position:'absolute',width:nw*fit,maxWidth:'none',height:nh*fit,left,top}}/></div>
 {label&&<div style={{fontFamily:F.sans,fontSize:20,letterSpacing:2,color:C.navy,paddingTop:13}}>UEB GONÇALVES DIAS</div>}
 </div>
};
const regions={bag:[0,0,650,625],lens:[650,0,604,615],dialogue:[0,640,725,614],shield:[735,615,519,639]} as const;
export type ObjectKind=keyof typeof regions;
export const Object3D:React.FC<{kind:ObjectKind;at:number;x:number;y:number;w:number;rotate?:number;scale?:number;float?:number;opacity?:number}>=({kind,at,x,y,w,rotate=0,scale=1,float=10,opacity=1})=>{
 const f=useCurrentFrame(),t=f/30,p=at===0?1:snap(f,at),[cx,cy,cw,ch]=regions[kind],s=w/cw,h=ch*s;
 return <div style={{position:'absolute',left:x,top:y,width:w,height:h,overflow:'hidden',opacity:p*opacity,transformOrigin:'50% 60%',transform:`translateY(${(1-p)*220+Math.sin((t-at)*1.7)*float}px) rotate(${rotate+(1-p)*-20+Math.sin((t-at)*.9)*1.8}deg) scale(${scale*(.6+.4*p)})`,filter:'drop-shadow(0 18px 14px #10274319)'}}><Img src={staticFile('assets/objetos-v2.png')} style={{position:'absolute',width:1254*s,maxWidth:'none',left:-cx*s,top:-cy*s}}/></div>
};
export const Table3D:React.FC<{at:number;x:number;y:number;w:number;rotate?:number;scale?:number}>=({at,x,y,w,rotate=0,scale=1})=>{
 const f=useCurrentFrame(),t=f/30,p=snap(f,at);return <Img src={staticFile('assets/mesa-comunidade-v2.png')} style={{position:'absolute',left:x,top:y,width:w,opacity:p,transform:`translateY(${(1-p)*190+Math.sin(t*1.2)*8}px) rotate(${rotate+(1-p)*12+Math.sin(t*.7)*1.1}deg) scale(${scale*(.8+.2*p)})`,filter:'drop-shadow(0 22px 20px #10274316)'}}/>
};
export const Target:React.FC<{x:number;y:number;size:number;at:number;color?:string}>=({x,y,size,at,color=C.gold})=>{
 const t=useTime(),p=ramp(t,at,at+.45);return <div style={{position:'absolute',left:x,top:y,width:size,height:size,borderRadius:'50%',border:`3px solid ${color}`,transform:`scale(${.55+.45*p})`,opacity:p}}>{[0,90,180,270].map(a=><div key={a} style={{position:'absolute',inset:0,transform:`rotate(${a}deg)`}}><div style={{position:'absolute',width:3,height:22,background:color,left:'50%',top:-12}}/></div>)}<div style={{position:'absolute',inset:14,borderRadius:'50%',border:`1px dashed ${color}`,transform:`rotate(${t*20}deg)`}}/></div>
};
export const PhotoStrip:React.FC<{at:number;y:number;motion?:number;w?:number}>=({at,y,motion=0,w=315})=>{
 const t=useTime();return <div style={{position:'absolute',inset:0,transform:`translateX(${motion}px)`}}>{(['front','courtyard','sign'] as SchoolView[]).map((view,i)=><RealPhoto key={view} view={view} x={40+i*(w+35)} y={y+Math.sin(t+i)*12} w={w} h={270} at={at+i*.08} rotate={(i-1)*5}/>)}</div>
};
