import React,{useEffect,useState} from 'react';
import {AbsoluteFill, Audio, Img, staticFile, useCurrentFrame,delayRender,continueRender,cancelRender} from 'remotion';
import cues from './cues.json';
import {C,F,fontCSS,Place,Type,Rule,Orbit,Route,School,Book,Badge,Shot,ramp,snap,useTime} from './motion';
const Q=cues;
const Intro:React.FC=()=>{const t=useTime();return <>
 <Shot from={0} to={3.28} chapter="GRUPAMENTO DE SEGURANÇA ESCOLAR" index={1} transition="none">
 <Place x={750} y={190} style={{fontFamily:F.serif,fontSize:640,color:'#1027430b',transform:`rotate(${12+t*4}deg)`}}>?</Place>
 <Place y={320}><Type text="Você já" at={0} size={160} face="serif" instant/></Place>
 <Place y={515}><Type text="PAROU" at={Q.parou} size={282} mode="letters"/></Place>
 <Place x={215} y={835}><Type text="pra pensar?" at={Q.pensar} size={140} face="serif"/></Place>
 <Place y={1030}><Type text="em tudo o que acontece" at={Q.tudo} size={45} face="sans"/></Place>
 <School at={0} y={1100} w={1090} x={70} rotation={-5}/><Orbit at={.2} y={1040} size={930} tilt={73}/>
 </Shot>
 <Shot from={3.28} to={Q.entraInicio} chapter="PARA MANTER UMA ESCOLA SEGURA" index={2} transition="slant">
 <Place y={250}><Type text="ESCOLA" at={Q.escola-.08} size={226} mode="turn"/></Place>
 <Place x={160} y={515}><Type text="SEGURA" at={Q.segura} size={232} mode="stretch"/></Place>
 <Place x={160} y={795}><Rule at={Q.segura} w={825}/></Place>
 <School at={3.14} y={700} x={-20} w={1160}/><Route at={Q.segura} path="M -50 1550 C 330 1250,1000 1800,1070 960"/>
 </Shot>
 </>};
const Identity:React.FC=()=>{const t=useTime(),f=useCurrentFrame();return <>
 <Shot from={Q.entraInicio} to={Q.somos} chapter="GRUPAMENTO DE SEGURANÇA ESCOLAR" index={3} bg={C.navy} dark transition="iris">
 <Orbit at={Q.entraInicio} x={-190} y={540} size={1400} tilt={50}/>
 <Place y={340}><Type text="É aí que" at={Q.entraInicio} size={180} face="serif" color={C.ice}/></Place>
 <Place x={175} y={620}><Type text="a gente" at={5.15} size={162} face="sans" color={C.ice}/></Place>
 <Place y={850}><Type text="ENTRA!" at={Q.entra} size={292} mode="stretch" color={C.ice}/></Place>
 <Place x={700} y={1250} style={{color:C.gold,fontSize:260,transform:`translateX(${Math.sin(t*4)*30}px) rotate(-25deg)`}}>↗</Place>
 <Route at={Q.entra} path="M -40 1560 Q 720 1660 840 1240"/>
 </Shot>
 <Shot from={Q.somos} to={Q.guarda} chapter="GRUPAMENTO DE SEGURANÇA ESCOLAR" index={4} transition="paper">
 <Place y={235}><Type text="Somos o" at={Q.somos} size={145} face="serif"/></Place>
 <Place y={385}><Type text="GSE" at={Q.gse} size={335} mode="letters"/></Place>
 <Orbit at={Q.gse} x={15} y={660} size={1060} tilt={25}/>
 <Badge at={Q.gse} x={226} y={740} w={628}/>
 <Place x={84} y={1445}><Type text="Grupamento de" at={Q.grupamento} size={69} face="sans"/></Place>
 <Place x={84} y={1540}><Type text="Segurança Escolar" at={Q.seguranca} size={96} face="serif"/></Place>
 <Place x={84} y={1690}><Rule at={Q.escolar} w={900}/></Place>
 </Shot>
 <Shot from={Q.guarda} to={11.98} chapter="GUARDA MUNICIPAL DE SÃO LUÍS" index={5} transition="hinge">
 <Place y={270}><Type text="Guarda" at={Q.guarda} size={162} face="serif"/></Place>
 <Place y={460}><Type text="MUNICIPAL" at={Q.guarda+.12} size={166} mode="spread"/></Place>
 <Badge at={Q.guarda-.12} kind="guarda" x={260} y={720} w={540}/>
 <Badge at={Q.guarda+.22} x={720} y={1260} w={230} plate/>
 <Place y={1470}><Type text="de São Luís." at={Q.saoluis} size={138} face="serif"/></Place>
 </Shot>
 </>};
const Mission:React.FC=()=>{const t=useTime(),f=useCurrentFrame();const burst=ramp(t,14.72,15.45);return <>
 <Shot from={11.98} to={Q.estamos} chapter="NOSSA MISSÃO" index={6} transition="slant">
 <Place y={285}><Type text="nossa missão" at={Q.missao-.16} size={144} face="serif"/></Place>
 <Place y={520}><Type text="MUITO" at={Q.muito} size={245} mode="spread"/></Place>
 <Place x={365} y={800}><Type text="ALÉM" at={Q.alem} size={230} mode="stretch" color={C.blue}/></Place>
 <Orbit at={12.3} x={-130} y={800} size={1350} tilt={64}/>
 <Place y={1170}><Type text="de fazer" at={13.8} size={108} face="serif"/></Place>
 <Place y={1320} style={{display:'flex',transform:`rotate(${-burst*9}deg)`}}>{[...'RONDAS'].map((c,i)=><div key={i} style={{transform:`translate(${(i-2.5)*burst*150}px,${burst*(i%2?-200:220)}px) rotate(${burst*(i-2)*17}deg)`,opacity:1-burst*.8}}><Type text={c} at={Q.rondas+i*.025} size={233} mode="turn"/></div>)}</Place>
 <Route at={Q.alem} path="M 65 1060 Q 580 1250 1040 960"/>
 </Shot>
 <Shot from={Q.estamos} to={Q.fortalecendo} chapter="ACOMPANHAMENTO / PREVENÇÃO" index={7} transition="iris">
 <Place y={260}>{t<Q.acompanhando?<><Type text="Estamos nas" at={Q.estamos} size={125} face="serif"/><Type text="ESCOLAS" at={Q.escolas} size={214} mode="letters"/></>:<><Type text="acompanhando" at={Q.acompanhando} size={104} face="sans"/><Type text="a rotina" at={Q.rotina-.1} size={160} face="serif"/></>}</Place>
 <div style={{position:'absolute',top:610,left:0,width:1080,height:830,overflow:'hidden'}}><School at={Q.estamos-.15} y={-240} x={-60+(t-Q.estamos)*12} w={1230} camera={1+Math.max(0,t-17)*.02}/></div>
 <Route at={Q.rotina} path="M -60 1300 C 200 1600 530 1020 750 1280 S 1060 1160 1180 830" width={6}/>
 <Place y={1480}><Type text="PREVENINDO" at={Q.prevenindo} size={151} mode="letters"/></Place>
 <Place x={280} y={1650}><Type text="situações de risco" at={Q.risco-.8} size={78} face="serif"/></Place>
 </Shot>
 </>};
const Education:React.FC=()=>{const t=useTime(),f=useCurrentFrame();return <>
 <Shot from={Q.fortalecendo} to={Q.acreditamos} chapter="QUEM ENSINA, APRENDE E TRABALHA" index={8} bg={C.blue} dark transition="paper">
 <Place y={270}><Type text="fortalecendo" at={Q.fortalecendo} size={112} face="serif" color={C.ice}/><Type text="a segurança" at={20.9} size={128} face="sans" color={C.ice}/></Place>
 <Route at={21} color="#ffffff55" path="M 0 980 C 750 500 1100 1300 100 1570" width={3}/>
 <Place x={84} y={680}><Type text="ENSINA" at={Q.ensina} size={238} mode="turn" color={C.ice}/></Place>
 <Place x={220} y={960}><Type text="aprende" at={Q.aprende} size={218} face="serif" color={C.ice}/></Place>
 <Place x={84} y={1250}><Type text="TRABALHA" at={Q.trabalha} size={181} mode="spread" color={C.ice} outline/></Place>
 <Place x={380} y={1500}><Type text="pela educação." at={Q.educacao-.2} size={100} face="serif" color={C.ice}/><Rule at={Q.educacao} w={580}/></Place>
 </Shot>
 <Shot from={Q.acreditamos} to={Q.presenca} chapter="SEGURANÇA TAMBÉM SE CONSTRÓI" index={9} transition="slant">
 <Place y={260}><Type text="Acreditamos" at={Q.acreditamos} size={135} face="serif"/></Place>
 <Place y={445}><Type text="SEGURANÇA" at={25.8} size={174} mode="letters"/></Place>
 <Book at={Q.acreditamos} y={720} x={-15} w={1120}/>
 <Place y={1480}><Type text="também se constrói" at={Q.constroi-.65} size={105} face="serif"/></Place>
 <Place x={755} y={1625}><Type text="com" at={27.48} size={90} face="sans" color={C.blue}/></Place>
 </Shot>
 </>};
const Community:React.FC=()=>{const t=useTime(),f=useCurrentFrame();const pp=snap(f,Q.presenca),dp=snap(f,Q.dialogo),rp=snap(f,Q.respeito),xp=snap(f,Q.proximidade);return <Shot from={Q.presenca} to={Q.moveInicio} chapter="COM A COMUNIDADE" index={10} transition="wipe">
 <Route at={Q.presenca} path="M 70 470 L 70 365 Q 70 310 126 310 L 990 310 L 990 760 Q 990 850 900 850 L 110 850 L 110 1160 Q 110 1240 200 1240 L 1015 1240" color={C.gold} width={6}/>
 <Place x={95} y={365} style={{transform:`translateX(${(1-pp)*-220}px)`}}><Type text="PRESENÇA" at={Q.presenca} size={185} mode="spread"/></Place>
 <Place x={320} y={610} style={{transform:`rotate(${(1-dp)*-24}deg)`,transformOrigin:'left center'}}><Type text="diálogo" at={Q.dialogo} size={230} face="serif"/></Place>
 <Place x={98} y={925} style={{transform:`scaleX(${.5+.5*rp})`,transformOrigin:'left center'}}><Type text="RESPEITO" at={Q.respeito} size={185} outline mode="stretch"/></Place>
 <Place x={98} y={1190}><Type text="PROXIMIDADE" at={Q.proximidade} size={143} mode="letters" color={C.blue}/></Place>
 <Book at={Q.dialogo} x={635} y={1370} w={390} rotation={-10}/>
 <Place x={98} y={1550}><Type text="com a" at={30.42} size={80} face="serif"/><Type text="comunidade." at={Q.comunidade} size={94} face="serif"/></Place>
 </Shot>};
const Purpose:React.FC=()=>{const t=useTime();const f=useCurrentFrame();return <>
 <Shot from={Q.moveInicio} to={Q.trabalhar} chapter="É ISSO QUE NOS MOVE" index={11} bg={C.navy} dark transition="hinge">
 <Place x={85} y={400}><Type text="É isso que" at={Q.moveInicio} size={150} face="serif" color={C.ice}/></Place>
 <Place x={570} y={615}><Type text="nos" at={32.58} size={180} face="serif" color={C.ice}/></Place>
 {[3,2,1].map(i=><Place key={i} x={75+i*20} y={880+i*30} style={{opacity:.1*i,transform:`translateX(${ramp(t,Q.move,33.4)*i*80}px)`}}><Type text="MOVE" at={Q.move} size={350} color={C.gold} outline/></Place>)}
 <Place y={880}><Type text="MOVE" at={Q.move} size={350} mode="stretch" color={C.ice}/></Place>
 <Route at={Q.move} path="M -40 1510 C 400 1510 600 1530 1170 1200"/>
 </Shot>
 <Shot from={Q.trabalhar} to={Q.protecao} chapter="ESCOLAS CADA VEZ MAIS SEGURAS" index={12} transition="slant">
 <Place y={270}>{t<Q.cada?<><Type text="trabalhar por" at={Q.trabalhar} size={140} face="serif"/><Type text="ESCOLAS" at={34.04} size={225} mode="letters"/></>:<><Type text="cada vez mais" at={Q.cada} size={140} face="serif"/><Type text="SEGURAS" at={Q.seguras} size={226} mode="stretch"/></>}</Place>
 <div style={{position:'absolute',top:690,left:0,width:1080,height:800,overflow:'hidden'}}><School at={Q.trabalhar-.12} x={-70} y={-220} w={1260} camera={.99+Math.max(0,t-34)*.015}/></div>
 <Route at={Q.cada} path="M -40 1650 Q 320 1640 450 1390 Q 720 1120 1150 1140"/>
 <Place y={1550}><Type text="ser referência" at={Q.referencia-.2} size={116} face="serif" color={C.blue}/></Place>
 </Shot>
 <Shot from={Q.protecao} to={Q.agora} chapter="NO AMBIENTE ESCOLAR" index={13} transition="paper">
 <Place y={295}><Type text="PROTEÇÃO" at={Q.protecao} size={204} mode="turn"/></Place>
 <Place x={350} y={545}><Type text="&" at={37.68} size={160} face="serif" color={C.gold}/></Place>
 <Place y={745}><Type text="PREVENÇÃO" at={Q.prevencao} size={181} mode="spread" color={C.blue}/></Place>
 <Book at={Q.protecao-.05} y={1040} x={-20} w={1120} rotation={-5}/>
 
 <Route at={Q.prevencao} path="M 44 250 L 44 950 Q 44 1000 120 1000 L 1040 1000"/>
 </Shot>
 </>};
const Card:React.FC<{x:number;y:number;rot:number;title:string;asset:string;at:number;w?:number}>=({x,y,rot,title,asset,at,w=660})=>{const f=useCurrentFrame(),t=f/30,p=snap(f,at);return <div style={{position:'absolute',left:x,top:y,width:w,height:860,background:C.ice,border:'2px solid #10274333',borderRadius:32,boxShadow:'0 28px 60px #1027431c',overflow:'hidden',transform:`perspective(1700px) translateY(${(1-p)*350}px) rotateY(${(1-p)*-18}deg) rotate(${rot+Math.sin(t)*.8}deg)`,opacity:p}}>
 <div style={{height:112,borderBottom:'1px solid #10274322',display:'flex',alignItems:'center',gap:18,padding:'20px 28px'}}><Img src={staticFile('assets/gse-original.png')} style={{width:62}}/><span style={{fontFamily:F.sans,fontWeight:600,fontSize:28,letterSpacing:3}}>GSE</span><span style={{marginLeft:'auto',fontFamily:F.sans,fontSize:27}}>•••</span></div>
 <Img src={staticFile(`assets/${asset}`)} style={{width:'100%',height:540,objectFit:'contain',marginTop:6}}/>
 <div style={{fontFamily:F.display,fontSize:84,position:'absolute',bottom:70,left:35,color:C.navy}}><Type text={title} at={title==='AÇÕES'?Q.acoes:title==='TRABALHO'?Q.trabalho:Q.dia} size={84}/></div>
 <div style={{position:'absolute',bottom:36,left:36,right:36,height:4,background:C.gold}}/>
 </div>};
const Social:React.FC=()=>{const t=useTime(),f=useCurrentFrame();const a=ramp(t,Q.trabalho-.1,Q.trabalho+.45),b=ramp(t,Q.dia-.1,Q.dia+.5),out=ramp(t,49.25,49.9),lift=ramp(t,47.75,48.5);return <Shot from={Q.agora} to={Q.nos} chapter="AÇÕES / TRABALHO / DIA A DIA" index={14} transition="iris">
 {t<43.92?<><Place y={250}><Type text="Agora," at={Q.agora} size={170} face="serif"/></Place><Place y={455}><Type text="você vai acompanhar" at={Q.acompanhar-.65} size={82} face="sans"/></Place><Place x={485} y={570}><Type text="por aqui." at={Q.aqui-.2} size={120} face="serif" color={C.blue}/></Place></>:t<45.12?<><Place y={250}><Type text="Nossas" at={43.92} size={160} face="serif"/></Place><Place y={445}><Type text="AÇÕES" at={Q.acoes} size={235} mode="letters"/></Place></>:t<46.16?<><Place y={250}><Type text="nosso" at={45.12} size={150} face="serif"/></Place><Place y={435}><Type text="TRABALHO" at={Q.trabalho} size={177} mode="spread"/></Place></>:<><Place y={250}><Type text="o dia a dia" at={Q.dia} size={160} face="serif"/></Place><Place y={460}><Type text="quem está presente" at={47.38} size={72} face="sans" color={C.blue}/></Place></>}
 <Orbit at={Q.acompanhar} x={-180} y={560} size={1440} tilt={70}/>
 <div style={{position:'absolute',inset:0,transformOrigin:'50% 60%',transform:`translateY(${out*60-lift*280}px) scale(${1-out*.16-lift*.13})`}}>
 <Card x={225-b*280} y={800+b*80} rot={-8-b*8} title="DIA A DIA" asset="escola-editorial.png" at={Q.agora+.25}/>
 <Card x={270+a*190-b*110} y={845-a*45+b*15} rot={7+a*5} title="TRABALHO" asset="comunidade-editorial.png" at={Q.acompanhar}/>
 <Card x={180-a*420-b*260} y={800+a*90} rot={-3-a*10} title="AÇÕES" asset="escola-editorial.png" at={Q.agora+.1}/>
 </div>
 <Place y={1440} x={84}><Type text="na missão de" at={48.02} size={96} face="serif"/><Type text="PROTEGER" at={Q.proteger} size={184} mode="stretch"/></Place>
 </Shot>};
const Closing:React.FC=()=>{const f=useCurrentFrame(),t=f/30;return <Shot from={Q.nos} to={Q.duration} chapter="GRUPAMENTO DE SEGURANÇA ESCOLAR" index={15} transition="iris">
 <Badge at={Q.nos} kind="guarda" x={875} y={210} w={95} rotate={false}/>
 <Place y={240}><Type text="Nós somos o" at={Q.nos} size={134} face="serif"/></Place>
 <Place y={410}><Type text="GSE" at={Q.gsefinal} size={320} mode="letters"/></Place>
 <Orbit at={Q.nos} x={65} y={725} size={950} tilt={35}/>
 <Badge at={Q.nos-.15} x={250} y={785} w={580}/>
 <Place y={1400}><Type text="Força" at={Q.forca} size={145} face="serif"/></Place><Place x={430} y={1400}><Type text="e" at={52.18} size={145} face="serif"/></Place>
 <Place x={400} y={1550}><Type text="HONRA" at={Q.honra} size={178} mode="stretch"/></Place>
 <Place y={1760}><Rule at={Q.forca} w={910}/></Place>
 </Shot>};
export const GSEFilm:React.FC=()=>{const [fontHandle]=useState(()=>delayRender('Loading licensed fonts'));useEffect(()=>{Promise.all([document.fonts.load('140px Instrument','Força e Honra'),document.fonts.load('180px Anton','SEGURANÇA PREVENÇÃO'),document.fonts.load('600 80px Space','ações presença')]).then(()=>continueRender(fontHandle)).catch(cancelRender);},[fontHandle]);return <AbsoluteFill style={{background:C.ice,fontFamily:F.sans}}><style>{fontCSS}</style><Audio src={staticFile('assets/narracao-original.mp3')}/><Intro/><Identity/><Mission/><Education/><Community/><Purpose/><Social/><Closing/></AbsoluteFill>};
