import React from 'react';
import {Img,staticFile,useCurrentFrame} from 'remotion';
import {C,F,ramp,snap,useTime} from './motion';

/** Architectural interpretation of the supplied UEB Gonçalves Dias references. */
export const SchoolUEB:React.FC<{at:number;x?:number;y?:number;w?:number;scale?:number;build?:number;rotation?:number}>=({at,x=35,y=850,w=1010,scale=1,build,rotation=0})=>{
 const f=useCurrentFrame(),t=f/30,p=at===0?1:snap(f,at),h=w*2/3;
 const style:React.CSSProperties={position:'absolute',left:x,top:y,width:w,height:h,opacity:p,transform:`translateY(${(1-p)*130}px) rotate(${rotation}deg) scale(${scale})`,transformOrigin:'50% 65%'};
 if(build!==undefined)return <div style={style}>{[0,1,2,3].map(i=>{const a=snap(f,build,(3-i)*3);return <div key={i} style={{position:'absolute',inset:0,clipPath:`inset(${i*25}% 0 ${75-i*25}% 0)`,opacity:a,transform:`translateY(${(1-a)*(140+i*40)}px)`}}><Img src={staticFile('assets/v3/escola-ueb.png')} style={{width:'100%'}}/></div>})}</div>;
 return <div style={style}><Img src={staticFile('assets/v3/escola-ueb.png')} style={{width:'100%',height:'100%'}}/></div>
};
const regions={bag:[0,0,650,625],lens:[650,0,604,615],dialogue:[0,640,725,614],shield:[735,615,519,639]} as const;
export const Object3D:React.FC<{kind:keyof typeof regions;at:number;x:number;y:number;w:number;rotate?:number;scale?:number;float?:number;opacity?:number}>=({kind,at,x,y,w,rotate=0,scale=1,float=10,opacity=1})=>{
 const f=useCurrentFrame(),t=f/30,p=at===0?1:snap(f,at),[cx,cy,cw,ch]=regions[kind],s=w/cw;
 return <div style={{position:'absolute',left:x,top:y,width:w,height:ch*s,overflow:'hidden',opacity:p*opacity,transformOrigin:'50% 60%',transform:`translateY(${(1-p)*160+Math.sin((t-at)*1.7)*float}px) rotate(${rotate+(1-p)*-16+Math.sin((t-at)*.9)*1.5}deg) scale(${scale*(.7+.3*p)})`}}><Img src={staticFile('assets/objetos-v2.png')} style={{position:'absolute',width:1254*s,maxWidth:'none',left:-cx*s,top:-cy*s}}/></div>
};
const cells={table:[0,0],chairNavy:[1,0],chairBlue:[2,0],clock:[0,1],bulb:[1,1],bell:[2,1]} as const;
export const Prop:React.FC<{kind:keyof typeof cells;at:number;x:number;y:number;w:number;rotation?:number;style?:React.CSSProperties}>=({kind,at,x,y,w,rotation=0,style})=>{
 const f=useCurrentFrame(),p=at===0?1:snap(f,at),[cx,cy]=cells[kind];
 return <div style={{position:'absolute',left:x,top:y,width:w,height:cy===0?w*.96:w,overflow:'hidden',opacity:p,transform:`translateY(${(1-p)*100}px) rotate(${rotation}deg) scale(${.85+.15*p})`,...style}}><Img src={staticFile('assets/v3/objetos.png')} style={{position:'absolute',width:3*w,maxWidth:'none',left:-cx*w,top:-cy*w}}/></div>
};
export const Clock:React.FC<{at:number;x:number;y:number;w:number;stop?:number}>=({at,x,y,w,stop})=>{
 const t=useTime(),f=useCurrentFrame(),p=at===0?1:snap(f,at),a=Math.max(0,(Math.min(t,stop??t)-at))*420, cx=w*.553,cy=w*.463;
 return <div style={{position:'absolute',left:x,top:y,width:w,height:w,opacity:p,transform:`scale(${.85+.15*p})`}}><Prop kind="clock" at={0} x={0} y={0} w={w}/><svg width={w} height={w} style={{position:'absolute',inset:0}}><g transform={`translate(${cx} ${cy})`}><g transform={`rotate(${a/12+70})`}><line y2={-w*.21} stroke={C.navy} strokeWidth={w*.025} strokeLinecap="round"/></g><g transform={`rotate(${a})`}><line y2={-w*.31} stroke={C.navy} strokeWidth={w*.018} strokeLinecap="round"/></g><circle r={w*.025} fill={C.gold}/></g></svg></div>
};
export const Bulb:React.FC<{at:number;on:number;x:number;y:number;w:number}>=({at,on,x,y,w})=>{const t=useTime(),p=ramp(t,on,on+.16);return <Prop kind="bulb" at={at} x={x} y={y} w={w} style={{filter:`saturate(${.05+p*.95}) brightness(${.68+p*.32}) drop-shadow(0 0 ${p*35}px #D6A54588)`}}/>};
export const Dome:React.FC<{at:number;x?:number;y?:number;w?:number;strength?:number}>=({at,x=95,y=800,w=890,strength=1})=>{
 const t=useTime(),p=ramp(t,at,at+.55);return <svg width={w} height={w*.78} viewBox="0 0 900 700" style={{position:'absolute',left:x,top:y,overflow:'visible',opacity:p}}><defs><linearGradient id={'dome'+at} x1="0" y1="0" x2="0" y2="1"><stop stopColor="#63B8E6" stopOpacity=".13"/><stop offset="1" stopColor="#63B8E6" stopOpacity=".015"/></linearGradient></defs><path d="M 15 575 A 435 490 0 0 1 885 575 Q 450 720 15 575" fill={`url(#dome${at})`} stroke={C.blue} strokeOpacity=".5" strokeWidth={2+strength*2} pathLength={1} strokeDasharray={1} strokeDashoffset={1-p}/><path d="M 55 560 A 395 450 0 0 1 845 560" fill="none" stroke={C.gold} strokeWidth={2+strength*2} pathLength={1} strokeDasharray={1} strokeDashoffset={1-p}/><circle cx="450" cy="86" r="19" fill={C.gold}/><path d="m441 86 6 6 14-15" stroke={C.navy} strokeWidth="4" fill="none"/></svg>
};
export const Gate:React.FC<{at:number;open:number;x?:number;y?:number;w?:number}>=({at,open,x=90,y=810,w=900})=>{
 const f=useCurrentFrame(),t=f/30,p=snap(f,at),o=ramp(t,open,open+.48),h=w*1079/1458;
 const full:React.CSSProperties={position:'absolute',inset:0,width:w,height:h};
 return <div style={{position:'absolute',left:x,top:y,width:w,height:h,perspective:1400,opacity:p,transform:`translateY(${(1-p)*100}px)`}}>
 <Img src={staticFile('assets/v3/portao-ueb.png')} style={{...full,clipPath:'polygon(0 0,100% 0,100% 100%,82.4% 100%,82.4% 36.5%,17.8% 36.5%,17.8% 100%,0 100%)'}}/>
 <div style={{position:'absolute',left:w*.205,top:h*.287,width:w*.59,textAlign:'center',fontFamily:F.sans,fontSize:w*.026,fontWeight:700,letterSpacing:1,color:C.navy}}>UEB GONÇALVES DIAS</div>
 <Img src={staticFile('assets/v3/portao-ueb.png')} style={{...full,clipPath:'inset(36.6% 50% 4.4% 17.8%)',transformOrigin:'17.8% 65%',transform:`rotateY(${-o*78}deg)`}}/>
 <Img src={staticFile('assets/v3/portao-ueb.png')} style={{...full,clipPath:'inset(36.6% 17.7% 4.4% 50%)',transformOrigin:'82.3% 65%',transform:`rotateY(${o*78}deg)`}}/>
 </div>
};
export const CommunityTable:React.FC<{at:number;respect:number;near:number}>=({at,respect,near})=>{
 const t=useTime(),space=ramp(t,respect,respect+.22),close=ramp(t,near,near+.66),d=space*70-close*180;
 return <><Prop kind="chairNavy" at={at} x={115-d} y={980} w={325}/><Prop kind="chairBlue" at={at+.08} x={650+d} y={980} w={325}/><Prop kind="table" at={at} x={290} y={950} w={500}/><svg viewBox="0 0 1080 1920" style={{position:'absolute',inset:0,width:1080,height:1920,opacity:ramp(t,near,near+.3)}}><path d={`M ${290-d} 1310 Q 540 ${1380-close*40} ${805+d} 1310`} fill="none" stroke={C.gold} strokeWidth="4" strokeDasharray="8 12"/></svg></>
};
