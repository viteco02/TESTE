import React,{useState,useEffect} from 'react';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame,delayRender,continueRender,cancelRender,Img} from 'remotion';
import Q from './cues.json';
import {C,F,fontCSS,Place,Type,Rule,Orbit,Route,Book,Badge,Shot,ramp,snap,useTime} from './motion';
import {RealPhoto,Object3D,Table3D,PhotoStrip,Target,SchoolView} from './visuals-v2';

const Opening:React.FC=()=>{const t=useTime();return <>
 <Shot from={0} to={3.28} chapter="GRUPAMENTO DE SEGURANÇA ESCOLAR" index={1} transition="none">
 <Place y={270}><Type text="Você já" at={0} size={154} face="serif" instant/></Place>
 <Place y={470}><Type text="PAROU" at={Q.parou} size={272} mode="letters"/></Place>
 <Place y={790}><Type text="pra pensar?" at={Q.pensar} size={142} face="serif"/></Place>
 <RealPhoto view="facade" x={360} y={1030} w={640} h={650} at={0} rotate={6} label/>
 <Object3D kind="bag" at={0} x={28} y={1110} w={430} rotate={-10}/>
 <Object3D kind="lens" at={Q.pensar} x={705} y={675} w={340} rotate={-18}/>
 <Place y={990}><Type text="em tudo o que acontece" at={Q.tudo} size={39} face="sans"/></Place>
 <Route at={Q.pensar} path="M -30 1560 Q 440 1680 620 1260 T 1050 1130"/>
 </Shot>
 <Shot from={3.28} to={Q.entraInicio} chapter="UEB GONÇALVES DIAS / SÃO LUÍS" index={2} transition="slant">
 <Place y={250}><Type text="ESCOLA" at={Q.escola-.08} size={224} mode="turn"/></Place>
 <Place x={160} y={510}><Type text="SEGURA" at={Q.segura} size={227} mode="stretch"/></Place>
 <RealPhoto view="facade" x={90} y={810} w={620} h={830} at={3.2} rotate={-5}/>
 <RealPhoto view="front" x={565} y={970} w={450} h={355} at={Q.escola} rotate={8}/>
 <Object3D kind="shield" at={Q.segura} x={705} y={1280} w={290} rotate={5}/>
 <Target x={105} y={1070} size={300} at={Q.segura}/>
 <Route at={Q.segura} path="M -20 1590 C 600 1590 850 1750 980 1300"/>
 </Shot>
 </>};
const Identity2:React.FC=()=>{const t=useTime();return <>
 <Shot from={Q.entraInicio} to={Q.somos} chapter="GRUPAMENTO DE SEGURANÇA ESCOLAR" index={3} bg={C.navy} dark transition="iris">
 <RealPhoto view="facade" x={785} y={630} w={280} h={920} at={Q.entraInicio} rotate={8}/>
 <Place y={340}><Type text="É aí que" at={Q.entraInicio} size={176} face="serif" color={C.ice}/></Place>
 <Place y={610}><Type text="a gente" at={5.15} size={158} face="sans" color={C.ice}/></Place>
 <Place y={840}><Type text="ENTRA!" at={Q.entra} size={249} mode="stretch" color={C.ice}/></Place>
 <Badge at={Q.entra} x={500} y={1250} w={310} plate/>
 <Route at={Q.entra} path="M -40 1540 Q 420 1630 675 1350"/>
 </Shot>
 <Shot from={Q.somos} to={Q.guarda} chapter="GRUPAMENTO DE SEGURANÇA ESCOLAR" index={4} transition="paper">
 <Place y={235}><Type text="Somos o" at={Q.somos} size={142} face="serif"/></Place>
 <Place y={385}><Type text="GSE" at={Q.gse} size={325} mode="letters"/></Place>
 <RealPhoto view="courtyard" x={80} y={950} w={920} h={410} at={Q.gse} rotate={-3}/>
 <Orbit at={Q.gse} x={70} y={650} size={940} tilt={40}/>
 <Badge at={Q.gse} x={260} y={750} w={560} plate/>
 <Place y={1455}><Type text="Grupamento de" at={Q.grupamento} size={67} face="sans"/></Place>
 <Place y={1550}><Type text="Segurança Escolar" at={Q.seguranca} size={94} face="serif"/></Place>
 <Place y={1700}><Rule at={Q.escolar} w={900}/></Place>
 </Shot>
 <Shot from={Q.guarda} to={11.98} chapter="GUARDA MUNICIPAL DE SÃO LUÍS" index={5} transition="hinge">
 <Place y={240}><Type text="Guarda" at={Q.guarda} size={154} face="serif"/></Place>
 <Place y={425}><Type text="MUNICIPAL" at={Q.guarda+.12} size={163} mode="spread"/></Place>
 <Badge at={Q.guarda-.12} kind="guarda" x={295} y={680} w={465}/>
 <Badge at={Q.guarda+.2} x={735} y={1000} w={220} plate/>
 <RealPhoto view="sign" x={84} y={1250} w={900} h={245} at={Q.guarda+.1} rotate={-2}/>
 <Place y={1535}><Type text="de São Luís." at={Q.saoluis} size={132} face="serif"/></Place>
 </Shot>
 </>};
const Mission2:React.FC=()=>{const t=useTime(),f=useCurrentFrame(),burst=ramp(t,14.72,15.45);return <>
 <Shot from={11.98} to={Q.estamos} chapter="NOSSA MISSÃO" index={6} transition="slant">
 <Place y={260}><Type text="nossa missão" at={Q.missao-.16} size={140} face="serif"/></Place>
 <Place y={460}><Type text="MUITO" at={Q.muito} size={218} mode="spread"/></Place>
 <Place x={430} y={730}><Type text="ALÉM" at={Q.alem} size={212} mode="stretch" color={C.blue}/></Place>
 <Object3D kind="lens" at={Q.alem} x={65} y={735} w={300} rotate={-15}/>
 <PhotoStrip at={Q.missao} y={1090} motion={-ramp(t,Q.rondas,15.25)*80}/>
 <Route at={Q.alem} path="M -20 1190 C 280 870 660 1500 1110 1120"/>
 <Place y={1420} style={{display:'flex'}}>{[...'RONDAS'].map((c,i)=><div key={i} style={{transform:`translate(${(i-2.5)*burst*150}px,${burst*(i%2?-200:220)}px) rotate(${burst*(i-2)*17}deg)`,opacity:1-burst*.8}}><Type text={c} at={Q.rondas+i*.02} size={215} mode="turn"/></div>)}</Place>
 </Shot>
 <Shot from={Q.estamos} to={Q.fortalecendo} chapter="ACOMPANHAMENTO / PREVENÇÃO" index={7} transition="iris">
 <Place y={245}>{t<Q.acompanhando?<><Type text="Estamos nas" at={Q.estamos} size={122} face="serif"/><Type text="ESCOLAS" at={Q.escolas} size={208} mode="letters"/></>:<><Type text="acompanhando" at={Q.acompanhando} size={103} face="sans"/><Type text="a rotina" at={Q.rotina-.1} size={154} face="serif"/></>}</Place>
 <RealPhoto view="facade" x={85} y={670} w={645} h={760} at={Q.estamos-.1} rotate={-4}/>
 <RealPhoto view="front" x={565} y={645} w={440} h={335} at={Q.acompanhando} rotate={8}/>
 <RealPhoto view="courtyard" x={500} y={1050} w={520} h={350} at={Q.rotina} rotate={5}/>
 <Route at={Q.rotina} path="M -30 1320 C 300 1550 850 950 1000 1330" width={6}/>
 <Object3D kind="lens" at={Q.prevenindo} x={580-Math.sin(Math.max(0,t-Q.prevenindo)*1.6)*160} y={1015} w={390} rotate={-22}/>
 <Target x={560} y={1080} size={255} at={Q.risco-.2}/>
 <Place y={1480}><Type text="PREVENINDO" at={Q.prevenindo} size={150} mode="letters"/></Place>
 <Place x={270} y={1650}><Type text="situações de risco" at={Q.risco-.8} size={80} face="serif"/></Place>
 </Shot>
 </>};
const Learning2:React.FC=()=>{const t=useTime();return <>
 <Shot from={Q.fortalecendo} to={21.82} chapter="FORTALECENDO A SEGURANÇA" index={8} bg={C.blue} dark transition="paper">
 <Place y={270}><Type text="fortalecendo" at={Q.fortalecendo} size={130} face="serif" color={C.ice}/></Place>
 <Place y={480}><Type text="a segurança" at={20.9} size={131} face="sans" color={C.ice}/></Place>
 <RealPhoto view="courtyard" x={80} y={855} w={730} h={500} at={Q.fortalecendo} rotate={-7}/>
 <Object3D kind="shield" at={21.06} x={580} y={795} w={390} rotate={5}/>
 <Route at={21.06} path="M 0 1480 Q 660 1670 1000 1100"/>
 </Shot>
 <Shot from={21.82} to={Q.acreditamos} chapter="QUEM ENSINA, APRENDE E TRABALHA" index={9} transition="wipe">
 <Place y={235}><Type text="de quem" at={21.82} size={100} face="serif"/></Place>
 <Place y={410}><Type text="ENSINA" at={Q.ensina} size={205} mode="turn"/></Place>
 <Object3D kind="bag" at={Q.ensina} x={660} y={620} w={345} rotate={8}/>
 <Place y={850}><Type text="aprende" at={Q.aprende} size={194} face="serif" color={C.blue}/></Place>
 <Book at={Q.aprende} x={490} y={1010} w={530} rotation={-9}/>
 <Place y={1400}><Type text="TRABALHA" at={Q.trabalha} size={164} mode="letters"/></Place>
 <Badge at={Q.trabalha} x={775} y={1445} w={190}/>
 <Place x={300} y={1640}><Type text="pela educação." at={Q.educacao-.15} size={98} face="serif"/></Place>
 <Route at={Q.ensina} path="M 50 700 C 300 730 1000 770 1010 1000 Q 1010 1230 140 1280" width={4}/>
 </Shot>
 <Shot from={Q.acreditamos} to={Q.presenca} chapter="SEGURANÇA TAMBÉM SE CONSTRÓI" index={10} transition="slant">
 <Place y={250}><Type text="Acreditamos" at={Q.acreditamos} size={131} face="serif"/></Place>
 <Place y={440}><Type text="SEGURANÇA" at={25.8} size={170} mode="letters"/></Place>
 <Table3D at={Q.acreditamos} x={90} y={725} w={900}/>
 <Place y={1550}><Type text="também se constrói" at={Q.constroi-.65} size={105} face="serif"/></Place>
 <Route at={Q.constroi} path="M 65 1360 Q 500 1580 1020 1350"/>
 </Shot>
 </>};
const Community2:React.FC=()=>{const t=useTime(),near=ramp(t,Q.proximidade,Q.proximidade+.65),respect=ramp(t,Q.respeito,Q.respeito+.4);return <Shot from={Q.presenca} to={Q.moveInicio} chapter="COM A COMUNIDADE" index={11} transition="wipe">
 <Place y={270}><Type text="PRESENÇA" at={Q.presenca} size={184} mode="spread"/></Place>
 <Place x={420} y={520}><Type text="diálogo" at={Q.dialogo} size={180} face="serif"/></Place>
 <RealPhoto view="facade" x={-165+near*210} y={690} w={440} h={610} at={Q.presenca} rotate={-9+near*7}/>
 <Object3D kind="dialogue" at={Q.dialogo} x={560} y={760} w={460} rotate={-6}/>
 <Table3D at={Q.presenca} x={325-near*30} y={940-respect*25} w={675} scale={1+respect*.05} rotate={respect*-4}/>
 <Place y={1350}><Type text="RESPEITO" at={Q.respeito} size={153} mode="stretch"/></Place>
 <Place y={1510}><Type text="PROXIMIDADE" at={Q.proximidade} size={138} mode="letters" color={C.blue}/></Place>
 <Route at={Q.presenca} path="M 80 540 L 80 1160 Q 80 1250 300 1260 C 680 1280 1000 1370 1000 1490" width={5}/>
 <Place x={360} y={1675}><Type text="com a comunidade." at={Q.comunidade-.1} size={61} face="serif"/></Place>
 </Shot>};
const Purpose2:React.FC=()=>{const t=useTime();return <>
 <Shot from={Q.moveInicio} to={Q.trabalhar} chapter="É ISSO QUE NOS MOVE" index={12} bg={C.navy} dark transition="hinge">
 <Place y={320}><Type text="É isso que" at={Q.moveInicio} size={150} face="serif" color={C.ice}/></Place>
 <Place x={570} y={550}><Type text="nos" at={32.58} size={165} face="serif" color={C.ice}/></Place>
 <Place y={770}><Type text="MOVE" at={Q.move} size={340} mode="stretch" color={C.ice}/></Place>
 <PhotoStrip at={Q.move} y={1270} motion={ramp(t,Q.move,33.6)*170-100}/>
 <Route at={Q.move} path="M -20 1650 Q 600 1640 1120 1170"/>
 </Shot>
 <Shot from={Q.trabalhar} to={Q.protecao} chapter="ESCOLAS CADA VEZ MAIS SEGURAS" index={13} transition="slant">
 <Place y={250}>{t<Q.cada?<><Type text="trabalhar por" at={Q.trabalhar} size={138} face="serif"/><Type text="ESCOLAS" at={34.04} size={220} mode="letters"/></>:<><Type text="cada vez mais" at={Q.cada} size={138} face="serif"/><Type text="SEGURAS" at={Q.seguras} size={220} mode="stretch"/></>}</Place>
 <RealPhoto view="facade" x={110} y={780} w={645} h={725} at={Q.trabalhar-.1} rotate={-5}/>
 <RealPhoto view="courtyard" x={565} y={945} w={450} h={325} at={Q.cada} rotate={7}/>
 <Object3D kind="shield" at={Q.seguras} x={720} y={1250} w={270}/>
 <Route at={Q.cada} path="M -30 1560 Q 620 1600 1020 1280"/>
 <Place y={1600}><Type text="ser referência" at={Q.referencia-.15} size={112} face="serif" color={C.blue}/></Place>
 </Shot>
 <Shot from={Q.protecao} to={Q.agora} chapter="NO AMBIENTE ESCOLAR" index={14} transition="paper">
 <Place y={270}><Type text="PROTEÇÃO" at={Q.protecao} size={201} mode="turn"/></Place>
 <Place x={700} y={505}><Type text="e" at={37.68} size={130} face="serif" color={C.gold}/></Place>
 <Place y={680}><Type text="PREVENÇÃO" at={Q.prevencao} size={179} mode="spread" color={C.blue}/></Place>
 <RealPhoto view="courtyard" x={110} y={1080} w={850} h={495} at={Q.protecao} rotate={-4}/>
 <Object3D kind="shield" at={Q.protecao} x={30} y={900} w={430} rotate={-8}/>
 <Object3D kind="lens" at={Q.prevencao} x={585-ramp(t,Q.ambiente,Q.ambiente+.6)*65} y={1310} w={405} rotate={-20}/>
 <Target x={625} y={1180} size={230} at={Q.ambiente}/>
 <Route at={Q.prevencao} path="M 45 940 Q 480 820 1010 1030 L 1010 1600"/>
 </Shot>
 </>};
const SocialPhoto:React.FC<{x:number;y:number;rot:number;title:string;view:SchoolView;at:number;titleAt:number}>=({x,y,rot,title,view,at,titleAt})=>{const f=useCurrentFrame(),t=f/30,p=snap(f,at);return <div style={{position:'absolute',left:x,top:y,width:650,height:850,background:'#fff',border:'2px solid #10274322',borderRadius:28,boxShadow:'0 25px 55px #10274326',overflow:'hidden',opacity:p,transform:`perspective(1600px) translateY(${(1-p)*280}px) rotateY(${(1-p)*-14}deg) rotate(${rot+Math.sin(t)*.7}deg)`}}>
 <div style={{height:105,display:'flex',alignItems:'center',gap:18,padding:'22px 28px',borderBottom:'1px solid #10274322'}}><Img src={staticFile('assets/gse-original.png')} style={{width:62}}/><span style={{fontFamily:F.sans,fontSize:27,fontWeight:600,letterSpacing:3}}>GSE</span><span style={{marginLeft:'auto',fontSize:26}}>•••</span></div>
 <RealPhoto view={view} x={20} y={130} w={610} h={510} at={at} bare/>
 <Place x={36} y={675}><Type text={title} at={titleAt} size={82}/></Place>
 <Place x={36} y={800}><Rule at={titleAt} w={578}/></Place>
 </div>};
const Social2:React.FC=()=>{const t=useTime(),a=ramp(t,Q.trabalho-.1,Q.trabalho+.45),b=ramp(t,Q.dia-.1,Q.dia+.5),lift=ramp(t,47.75,48.5);return <Shot from={Q.agora} to={Q.nos} chapter="AÇÕES / TRABALHO / DIA A DIA" index={15} transition="iris">
 {t<43.92?<><Place y={250}><Type text="Agora," at={Q.agora} size={166} face="serif"/></Place><Place y={455}><Type text="você vai acompanhar" at={Q.acompanhar-.65} size={82} face="sans"/></Place><Place x={485} y={575}><Type text="por aqui." at={Q.aqui-.2} size={116} face="serif" color={C.blue}/></Place></>:t<45.12?<><Place y={250}><Type text="Nossas" at={43.92} size={156} face="serif"/></Place><Place y={445}><Type text="AÇÕES" at={Q.acoes} size={227} mode="letters"/></Place></>:t<46.16?<><Place y={250}><Type text="nosso" at={45.12} size={148} face="serif"/></Place><Place y={435}><Type text="TRABALHO" at={Q.trabalho} size={174} mode="spread"/></Place></>:<><Place y={250}><Type text="o dia a dia" at={Q.dia} size={156} face="serif"/></Place><Place y={460}><Type text="quem está presente" at={47.38} size={72} face="sans" color={C.blue}/></Place></>}
 <Orbit at={Q.acompanhar} x={-150} y={650} size={1380} tilt={75}/>
 <div style={{position:'absolute',inset:0,transformOrigin:'50% 60%',transform:`translateY(${-lift*280}px) scale(${1-lift*.13})`}}>
 <SocialPhoto x={225-b*280} y={810+b*80} rot={-8-b*8} title="DIA A DIA" view="courtyard" at={Q.agora+.25} titleAt={Q.dia}/>
 <SocialPhoto x={270+a*190-b*110} y={850-a*45+b*15} rot={7+a*5} title="TRABALHO" view="front" at={Q.acompanhar} titleAt={Q.trabalho}/>
 <SocialPhoto x={180-a*420-b*260} y={810+a*90} rot={-3-a*10} title="AÇÕES" view="facade" at={Q.agora+.1} titleAt={Q.acoes}/>
 </div>
 <Place y={1440}><Type text="na missão de" at={48.02} size={96} face="serif"/><Type text="PROTEGER" at={Q.proteger} size={183} mode="stretch"/></Place>
 </Shot>};
const Ending2:React.FC=()=> <Shot from={Q.nos} to={Q.duration} chapter="GRUPAMENTO DE SEGURANÇA ESCOLAR" index={16} transition="iris">
 <Badge at={Q.nos} kind="guarda" x={875} y={210} w={95} rotate={false}/>
 <Place y={240}><Type text="Nós somos o" at={Q.nos} size={134} face="serif"/></Place>
 <Place y={410}><Type text="GSE" at={Q.gsefinal} size={320} mode="letters"/></Place>
 <Orbit at={Q.nos} x={65} y={725} size={950} tilt={35}/>
 <Badge at={Q.nos-.15} x={250} y={785} w={580}/>
 <Place y={1400}><Type text="Força" at={Q.forca} size={145} face="serif"/></Place><Place x={430} y={1400}><Type text="e" at={52.18} size={145} face="serif"/></Place>
 <Place x={400} y={1530}><Type text="HONRA" at={Q.honra} size={164} mode="stretch"/></Place>
 <Place y={1750}><Rule at={Q.forca} w={910}/></Place>
 </Shot>;
export const GSEFilmV2:React.FC=()=>{
 const [handle]=useState(()=>delayRender('Loading editorial fonts'));
 useEffect(()=>{Promise.all([document.fonts.load('140px Instrument','Força e Honra'),document.fonts.load('180px Anton','SEGURANÇA PREVENÇÃO'),document.fonts.load('600 80px Space','ações presença')]).then(()=>continueRender(handle)).catch(cancelRender)},[handle]);
 return <AbsoluteFill style={{background:C.ice,fontFamily:F.sans}}><style>{fontCSS}</style><Audio src={staticFile('assets/narracao-original.mp3')}/><Opening/><Identity2/><Mission2/><Learning2/><Community2/><Purpose2/><Social2/><Ending2/></AbsoluteFill>
};
