"""Package editable sources and all retained assets without dependency caches."""
from pathlib import Path
import json,zipfile
ROOT=Path(__file__).resolve().parents[1]
validation=json.loads((ROOT/'analysis/v3/DELIVERY_VALIDATION.json').read_text())
assert validation['full_decode']=='passed'
out=ROOT/'out/v3/GSE_REMOTION_PROJETO_V3.zip'
files=[]
for name in ['README.md','STATUS.md','package.json','package-lock.json','tsconfig.json','requirements-analysis.txt']:
 files.append(ROOT/name)
for directory in ['src','public','scripts','references']:
 files.extend(p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for p in (ROOT/'analysis').rglob('*'):
 if p.is_file() and (p.suffix in ['.json','.md','.py'] or p.name=='audio-pauses.log'):
  files.append(p)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for file in sorted(set(files)):
  archive.write(file,Path('GSE_Remotion_V3')/file.relative_to(ROOT))
with zipfile.ZipFile(out) as archive:
 assert archive.testzip() is None
 required=['src/film-v3.tsx','src/visuals-v3.tsx','public/assets/v3/escola-ueb.png','public/assets/v3/portao-ueb.png','public/assets/v3/objetos.png','public/assets/real-school/fachada.jpg','public/assets/real-school/fachada-patio.jpg','public/assets/real-school/entrada.jpg','analysis/v3/DELIVERY_VALIDATION.json']
 assert all('GSE_Remotion_V3/'+name in archive.namelist() for name in required)
 print(json.dumps({'file':str(out),'bytes':out.stat().st_size,'files':len(archive.namelist())},indent=2))
