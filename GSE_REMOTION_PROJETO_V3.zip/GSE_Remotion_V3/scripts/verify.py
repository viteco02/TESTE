"""Verify the delivered render, source-asset identity and narration continuity."""
import sys,json,subprocess,hashlib,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'python-packages'))
import numpy as np
final=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'out/v3/GSE_MOTION_FINAL.mp4'
def probe(path):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)]))
def pcm(path):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-map','0:a:0','-acodec','pcm_s16le','-ar','44100','-ac','2','-f','s16le','-']),dtype=np.int16).reshape(-1,2)
p=probe(final);v=next(s for s in p['streams'] if s['codec_type']=='video');a=next(s for s in p['streams'] if s['codec_type']=='audio')
x=pcm(ROOT/'public/assets/narracao-original.mp3');y=pcm(final);duration=len(x)/44100
assert (v['width'],v['height'])==(1080,1920)
assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p' and v['r_frame_rate']=='30/1'
assert int(v['nb_frames'])==math.ceil(duration*30)
assert a['codec_name']=='aac' and int(a['sample_rate'])==44100
assert abs(float(p['format']['duration'])-duration)<.0001
assert abs(float(a['duration'])-duration)<.0001
assert len(y)>=len(x),'Narration samples missing from the decoded AAC'
y=y[:len(x)].astype(np.float64);x=x.astype(np.float64)
corr=float(np.sum(x*y)/np.sqrt(np.sum(x*x)*np.sum(y*y)))
assert corr>.995,f'Unexpected narration difference: {corr}'
regions=[]
for start,end in [(0,2),(25,27),(49.7,52.9)]:
 xx=x[int(start*44100):int(end*44100)];yy=y[int(start*44100):int(end*44100)]
 c=float(np.sum(xx*yy)/np.sqrt(np.sum(xx*xx)*np.sum(yy*yy)));assert c>.995
 regions.append({'from':start,'to':end,'correlation':c})
assets={}
for remote,local in [('LOGO.png','gse-original.png'),('LOGO GUARDA.png','guarda-original.png'),('1019 (1).MP3','narracao-original.mp3')]:
 original=subprocess.check_output(['git','-C','/workspace/TESTE','show','FETCH_HEAD:'+remote]);data=(ROOT/'public/assets'/local).read_bytes()
 assert original==data,f'Original changed: {local}'
 assets[local]=hashlib.sha256(data).hexdigest()
if final.parent.name in ['v2','v3']:
 photo_manifest=json.loads((ROOT/'analysis/v2/photo-originals.json').read_text())
 for name,meta in photo_manifest.items():
  photo=ROOT/'public/assets/real-school'/name
  digest=hashlib.sha256(photo.read_bytes()).hexdigest()
  assert digest==meta['sha256'],f'School photograph changed: {name}'
  assets['real-school/'+name]=digest
 for source in (['film-v2.tsx','visuals-v2.tsx'] if final.parent.name=='v2' else ['film-v3.tsx','visuals-v3.tsx']):
  assert 'escola-editorial.png' not in (ROOT/'src'/source).read_text(), 'Generic school asset remains in active composition'
 if final.parent.name=='v3':
  for source in ['film-v3.tsx','visuals-v3.tsx']:
   text=(ROOT/'src'/source).read_text()
   assert all(term not in text for term in ['RealPhoto','PhotoStrip','SocialPhoto','assets/real-school/','visuals-v2']),f'Photograph card remains in V3: {source}'
  for name in ['escola-ueb.png','portao-ueb.png','objetos.png']:
   file=ROOT/'public/assets/v3'/name
   assert file.is_file() and file.stat().st_size>10000
   assets['v3/'+name]=hashlib.sha256(file.read_bytes()).hexdigest()
 assert v.get('color_range')=='tv' and v.get('color_space')=='bt709'
subprocess.run(['ffmpeg','-v','error','-i',str(final),'-f','null','-'],check=True)
report={'file':str(final),'sha256':hashlib.sha256(final.read_bytes()).hexdigest(),'bytes':final.stat().st_size,'video':{'codec':v['codec_name'],'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'frames':v['nb_frames'],'pixel_format':v['pix_fmt']},'audio':{'codec':a['codec_name'],'rate':a['sample_rate'],'channels':a['channels'],'duration':a['duration'],'source_duration':duration,'source_samples':len(x),'waveform_correlation':corr,'regions':regions},'format_duration':p['format']['duration'],'original_asset_sha256':assets,'full_decode':'passed'}
(ROOT/(f'analysis/{final.parent.name}/DELIVERY_VALIDATION.json' if final.parent.name in ['v2','v3'] else 'analysis/DELIVERY_VALIDATION.json')).write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
