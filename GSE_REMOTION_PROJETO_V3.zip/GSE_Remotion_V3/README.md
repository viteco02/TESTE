# GSE — Primeiro Reels / versão 3

Projeto editável em React, TypeScript e Remotion, 1080×1920, 30 fps. A composição principal **GSE** usa uma interpretação ilustrada da **UEB Gonçalves Dias**, baseada nas três fotografias fornecidas pelo usuário. Ela substitui a escola genérica da primeira montagem. As fotos servem apenas como referência arquitetônica: não aparecem como cartões ou slideshow nesta versão.

A narração original tem 53.05469387755102 segundos. Brasões e MP3 originais são preservados nos arquivos de origem. **GSE-V1** e **GSE-V2** mantêm as montagens históricas para comparação.

## Executar e renderizar

Requisitos: Node.js 24, npm, Python 3.12, FFmpeg/ffprobe e Chromium. Ajuste `/usr/bin/chromium` nos scripts se o navegador tiver outro caminho.

```bash
npm ci
python -m pip install --target ./python-packages -r requirements-analysis.txt
npm run check
npm run preview
```

```bash
npm run render:preview
npm run render
python scripts/verify.py out/v3/GSE_MOTION_FINAL.mp4
python scripts/package-project.py
```

A prévia vai para `out/v3/GSE_PREVIEW.mp4`; a exportação final, para `out/v3/GSE_MOTION_FINAL.mp4`. A finalização codifica a narração original diretamente em AAC a 192 kbit/s e converte o master para H.264/yuv420p, BT.709 com faixa limitada. São 1592 quadros em cadência de 30 fps. Apenas a duração de exibição do último quadro é reduzida em cerca de 12 ms para coincidir com o término exato da voz. Não há cortes, substituição ou alteração de velocidade da narração.

## Editar

- `src/film-v3.tsx`: sequência, tipografia, metáforas visuais e sincronização da versão atual.
- `src/visuals-v3.tsx`: escola, folhas móveis do portão, relógio com ponteiros, lâmpada, cadeiras, mesa e proteção.
- `src/motion.tsx`: máscaras, fontes, curvas, brasões e transições reutilizáveis.
- `src/cues.json`: tempos de palavras da narração.
- `public/assets/v3/`: escola reconstruída como ilustração, portão e atlas de objetos.
- `public/assets/real-school/`: fotografias originais, conservadas apenas como referências na versão 3.
- `analysis/v3/semantic-events.json`: mapa das palavras e animações correspondentes.
- `analysis/v3/DELIVERY_VALIDATION.json`: validação técnica e integridade dos originais.
- `src/film.tsx`, `src/film-v2.tsx`: versões históricas.

A escola ilustrada reproduz os elementos reconhecíveis das referências — edifícios térreos, telhados cerâmicos, pilares e portão azuis, paredes claras e bancos vermelhos do pátio. É uma interpretação artística, sem pretensão de levantamento arquitetônico exato. Os objetos ilustrativos foram gerados para a composição. A interface de celular é conceitual, sem inventar publicações, métricas ou ocorrências reais.

Fontes: Anton, Instrument Serif e Space Grotesk; arquivos e licenças OFL acompanham os assets. Não substitua os brasões por reconstruções. Os arquivos de origem são verificados por hash e a narração exportada é comparada por forma de onda. A análise auxiliar de voz pode conter erros de transcrição; os textos visuais seguem o roteiro.

Os arquivos anteriores não são sobrescritos. A entrega pública desta revisão recebe o nome `GSE_MOTION_FINAL_V3.mp4`, acompanhada por `GSE_REMOTION_PROJETO_V3.zip`.
