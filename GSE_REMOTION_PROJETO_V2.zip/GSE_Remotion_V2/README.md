# GSE — Primeiro Reels / versão 2

Projeto editável em React, TypeScript e Remotion, 1080×1920, 30 fps.
A composição principal **GSE** corresponde à versão 2, com fotografias reais da UEB Gonçalves Dias e objetos sincronizados à narração. A composição **GSE-V1** mantém a montagem anterior para comparação. Duração da narração original: 53.05469387755102 segundos.

## Dependências

Node.js 24 (usado nesta produção), npm, Python 3.12, FFmpeg/ffprobe e Chromium.
O render usa `/usr/bin/chromium`; ajuste `--browser-executable` nos scripts se necessário em outro sistema.

```bash
npm ci
python -m pip install --target ./python-packages -r requirements-analysis.txt
npm run check
npm run preview
```

`npm run preview` abre o Remotion Studio para edição local. Nenhum servidor persistente é necessário para renderizar.

```bash
npm run render:preview
npm run render
```

A prévia integral vai para `out/v2/GSE_PREVIEW.mp4`. A entrega vai para `out/v2/GSE_MOTION_FINAL.mp4`.
`npm run render` produz o master em resolução integral e executa o acabamento de áudio/duração.

## Edição

- `src/film-v2.tsx`: composições e sequência principal da versão 2.
- `src/visuals-v2.tsx`: fotografias reais, enquadramentos, objetos editoriais e animações.
- `src/film.tsx`: montagem original, mantida para comparação.
- `src/motion.tsx`: tipografia, máscaras, curvas, câmera, objetos e transições reutilizáveis.
- `src/cues.json`: tempos de palavras extraídos do áudio.
- `public/assets/`: imagens, brasões, narração original, fontes e licenças.
- `analysis/alignment.json`: transcrição automática com timestamps por palavra.
- `analysis/words-refined.json`: ajustes baseados em pausas detectadas, com rastreabilidade dos valores originais.
- `scripts/finalize.py`: áudio e duração do MP4.
- `analysis/v2/DELIVERY_VALIDATION.json`: resultados da validação desta entrega.

Os nomes das fontes são escolhas de adaptação, não uma identificação exata das fontes da referência. As fotografias da escola foram fornecidas pelo usuário e são mantidas sem alteração nos arquivos de origem em `public/assets/real-school`. Os enquadramentos são feitos na composição, sem reconstruir a arquitetura ou gerar versões artificiais da escola. Os objetos ilustrativos (mochila, lupa, proteção em vidro, formas de diálogo, mesa e livro) foram gerados para o projeto e não são registros de equipamentos ou ações reais do GSE. A antiga ilustração de escola é usada apenas na composição histórica GSE-V1, sem participação na versão 2. A interface de redes sociais é conceitual, sem publicações, métricas, perfis ou acontecimentos fictícios apresentados como reais.

## Áudio e duração

O áudio original é preservado integralmente, sem cortes, substituição ou mudanças de velocidade. O acabamento o codifica diretamente em AAC a 192 kbit/s. O vídeo contém 1592 quadros em cadência de 30 fps. O último quadro tem sua duração de exibição encurtada em aproximadamente 12 ms para coincidir com o fim exato da narração; isso não altera os movimentos nem o áudio.

Não substitua os brasões por reconstruções e mantenha os arquivos originais. Para uma nova sincronização do mesmo áudio, `python analysis/transcribe.py` usa faster-whisper small (download do modelo exigido na primeira execução), e `python analysis/build-cues.py` atualiza os cues com os registros de pausas existentes. A transcrição auxiliar pode conter erros ortográficos; os textos visuais foram escritos conforme o roteiro oficial.

O projeto usa o workspace isolado existente. Não é necessário criar Git worktrees.

## Fotografias e eventos da versão 2

As três fotografias originais têm dimensões 495×619, 495×619 e 416×738 pixels. Foram usadas em molduras editoriais e recortes de fachada, pátio e identificação da escola, respeitando a resolução disponível. Os hashes de preservação estão em `analysis/v2/photo-originals.json`. O mapa de palavras, tempos e objetos correspondentes está em `analysis/v2/semantic-events.json`.

Os arquivos anteriores de vídeo e do projeto não são sobrescritos. A entrega pública desta versão recebe o nome GSE_MOTION_FINAL_V2.mp4.
