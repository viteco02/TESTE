# GSE — versão 2 concluída

Entrega: out/v2/GSE_MOTION_FINAL.mp4.
1080×1920, 30 fps, H.264/yuv420p, AAC estéreo, 53.054694 segundos.

A composição principal GSE usa as fotografias reais da UEB Gonçalves Dias e objetos associados às palavras da narração. As fotografias, os brasões e o MP3 originais foram preservados byte a byte. A escola genérica não integra a versão 2.

Foram renderizadas a prévia integral e duas exportações de revisão. Os ajustes de rodapé e de máscara para acentos foram aplicados e conferidos em quadros da exportação final. A decodificação integral, os codecs, a duração, a continuidade da voz e os hashes dos arquivos originais passaram na validação. Os resultados estão em analysis/v2/DELIVERY_VALIDATION.json e a revisão visual em analysis/v2/VISUAL_REVIEW.md.

O projeto editável usa src/film-v2.tsx, src/visuals-v2.tsx e src/motion.tsx. Os arquivos da versão anterior estão preservados em out/. A composição GSE-V1 permite comparar a montagem anterior.

Não há bloqueios de produção pendentes. A entrega pelo GitHub tem seu registro em analysis/v2/github-delivery.json após a publicação dos arquivos.
