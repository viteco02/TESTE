"""Mux the untouched full narration, then fit the final video sample to its duration.
The frame cadence remains 30 fps; only the display duration of the final frame is
shortened to the exact audio endpoint. No speech is cut or time-stretched.
"""
import sys,os,json,subprocess
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'python-packages'))
import av
master=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'out/GSE_RENDER_MASTER.mp4'
output=Path(sys.argv[2]) if len(sys.argv)>2 else ROOT/'out/GSE_MOTION_FINAL.mp4'
audio=ROOT/'public/assets/narracao-original.mp3'
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(audio)]))['streams'][0]
rate=int(info['sample_rate']);channels=int(info['channels'])
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(audio),'-map','0:a:0','-c:a','pcm_s16le','-f','s16le','-'])
samples=len(raw)//(channels*2); duration=Fraction(samples,rate)
intermediate=output.with_name(output.stem+'-mux-intermediate.mp4')
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(master),'-i',str(audio),'-map','0:v:0','-map','1:a:0','-vf','scale=in_range=pc:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709,format=yuv420p','-c:v','libx264','-preset','medium','-crf','17','-profile:v','high','-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-threads','4','-c:a','aac','-b:a','192k','-ar',str(rate),'-movie_timescale',str(rate),'-movflags','+faststart',str(intermediate)],check=True)
with av.open(str(intermediate)) as ic:
 with av.open(str(output),'w',options={'movflags':'+faststart','movie_timescale':str(rate)}) as oc:
  mapping={s.index:oc.add_stream_from_template(s) for s in ic.streams}
  for packet in ic.demux():
   if packet.dts is None:continue
   if packet.pts is not None and packet.pts>=0:
    endpoint=round(duration/packet.time_base)
    available=endpoint-packet.pts
    if available<=0:continue
    if packet.duration and packet.duration>available:packet.duration=available
   packet.stream=mapping[packet.stream.index]
   oc.mux(packet)
intermediate.unlink()
report={'source_samples_per_channel':samples,'source_sample_rate':rate,'source_duration_seconds':float(duration),'final_file':str(output),'method':'Full original narration encoded to AAC at 192k; video converted from full-range BT.601 to limited-range BT.709 yuv420p and encoded in H.264 CRF 17; last display sample shortened to audio endpoint; no narration cuts or speed changes.'}
(ROOT/('analysis/v2/final-mux-report.json' if output.parent.name=='v2' else 'analysis/final-mux-report.json')).write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
